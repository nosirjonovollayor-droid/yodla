import os
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).resolve().parent.parent / ".env")
except Exception:
    pass


def env(key, default=""):
    return os.getenv(key, default).strip()


USER_BOT_TOKEN = env("USER_BOT_TOKEN")
USER_BOT_USERNAME = env("USER_BOT_USERNAME", "yodla_bot").lstrip("@")
ADMIN_BOT_TOKEN = env("ADMIN_BOT_TOKEN")
ADMIN_IDS = [int(x) for x in env("ADMIN_IDS").split(",") if x.strip().isdigit()]

OPENROUTER_API_KEY = env("OPENROUTER_API_KEY")
OPENROUTER_MODEL = env("OPENROUTER_MODEL", "anthropic/claude-sonnet-4.5")

BASE_URL = env("BASE_URL", "http://localhost:8000").rstrip("/")
TIMEZONE = env("TIMEZONE", "Asia/Tashkent")
DB_PATH = env("DB_PATH", "data/yodla.db")
AI_DAILY_LIMIT = int(env("AI_DAILY_LIMIT", "60") or 60)
COOKIE_SECURE = env("COOKIE_SECURE", "0") == "1"

# ---- tariflar ----
PAY_CONTACT = env("PAY_CONTACT", "@yodla_admin")  # to'lov uchun admin Telegram manzili
TRIAL_DAYS = int(env("TRIAL_DAYS", "7") or 7)
OPENROUTER_MODEL_ULTRA = env("OPENROUTER_MODEL_ULTRA") or OPENROUTER_MODEL


def model_for(plan):
    return OPENROUTER_MODEL_ULTRA if plan == "ultra" else OPENROUTER_MODEL
