"""Yodla veb-serveri: sayt + API."""
import asyncio
import re
import time
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Literal, Optional

from fastapi import Depends, FastAPI, HTTPException, Request, Response
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import ai, config, db, notify, plans
from .plans import PLANS

STATIC = Path(__file__).resolve().parent.parent / "static"
COOKIE = "yt"
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
AI_BUSY = "Domla hozir band, birozdan keyin qayta urinib ko'r 😅"


@asynccontextmanager
async def lifespan(app):
    db.init()
    task = asyncio.create_task(notify.loop())
    yield
    task.cancel()


app = FastAPI(lifespan=lifespan, docs_url=None, redoc_url=None)
app.mount("/static", StaticFiles(directory=STATIC), name="static")


@app.get("/")
async def index():
    return FileResponse(STATIC / "index.html")


# ---------- kirish va profil ----------
def current_user(request: Request):
    token = request.cookies.get(COOKIE)
    u = db.user_by_token(token) if token else None
    if not u:
        raise HTTPException(401, "Kirish kerak")
    return u


def me_payload(u):
    u = db.user_by_id(u["id"])
    plan = db.effective_plan(u)
    P = PLANS[plan]
    uid = u["id"]
    return {
        "name": u["name"], "surname": u["surname"], "email": u["email"], "lang": u["lang"],
        "daily": min(u["daily"], P["words"]), "monthly": u["monthly"], "domla": u["domla"],
        "streak": db.effective_streak(u), "done": db.daily_done(uid), "total": db.total_learned(uid),
        "notify_hour": u["notify_hour"], "notify_on": bool(u["notify_on"]),
        "tg": u["tg_chat_id"] is not None, "bot": config.USER_BOT_USERNAME,
        "plan": plan, "plan_until": u["plan_until"] if plan != "free" else None,
        "trial_used": bool(u["trial_used"]), "pay": config.PAY_CONTACT,
        "limits": {"words": P["words"],
                   "ai_left": max(0, P["ai"] - db.used(uid, "ai")), "ai": P["ai"],
                   "essay_left": max(0, P["essay"] - db.used(uid, "essay")), "essay": P["essay"],
                   "speak_left": max(0, P["speak"] - db.used(uid, "speak")), "speak": P["speak"],
                   "quiz_left": max(0, P["quiz"] - db.used(uid, "quiz")), "quiz": P["quiz"]},
    }


def set_cookie(response: Response, token: str):
    response.set_cookie(COOKIE, token, max_age=db.SESSION_DAYS * 86400, httponly=True,
                        samesite="lax", secure=config.COOKIE_SECURE)


def start_plan(u, plan):
    """Free: darrov. Max/Ultra: faqat bepul foydalanuvchi uchun sinov muddati."""
    if plan == "free":
        return
    if db.effective_plan(u) != "free" or u["trial_used"]:
        raise HTTPException(402, f"Pullik tarif uchun {config.PAY_CONTACT} ga yozing, tez faollashtirib beramiz")
    db.update_user(u["id"], plan=plan, plan_until=db.day_plus(config.TRIAL_DAYS), trial_used=1)


class RegisterIn(BaseModel):
    name: str = Field(min_length=1, max_length=40)
    surname: str = Field(min_length=1, max_length=40)
    email: str = Field(max_length=120)
    password: str = Field(min_length=6, max_length=128)
    lang: Literal["en", "ru"]
    daily: int = Field(ge=1, le=100)
    monthly: int = Field(ge=1, le=3000)
    domla: Literal["h", "q"] = "h"
    plan: Literal["free", "max", "ultra"] = "free"


class LoginIn(BaseModel):
    email: str = Field(max_length=120)
    password: str = Field(max_length=128)


_fails = {}


def _throttled(key):
    now = time.time()
    _fails[key] = [t for t in _fails.get(key, []) if now - t < 600]
    return len(_fails[key]) >= 8


@app.post("/api/register")
async def register(data: RegisterIn, response: Response):
    email = data.email.strip().lower()
    if not EMAIL_RE.match(email):
        raise HTTPException(400, "Email noto'g'ri ko'rinyapti")
    if db.user_by_email(email):
        raise HTTPException(409, "Bu email bilan hisob bor, kirishni bos")
    uid = db.create_user(data.name.strip(), data.surname.strip(), email, data.password,
                         data.lang, data.daily, data.monthly, data.domla)
    start_plan(db.user_by_id(uid), data.plan)
    set_cookie(response, db.new_session(uid))
    await notify.send_admin(f"🆕 Yangi foydalanuvchi: {data.name} {data.surname} "
                            f"({'🇬🇧' if data.lang == 'en' else '🇷🇺'}) · tarif: {data.plan}")
    return me_payload(db.user_by_id(uid))


@app.post("/api/login")
async def login(data: LoginIn, request: Request, response: Response):
    email = data.email.strip().lower()
    key = (request.client.host if request.client else "?", email)
    if _throttled(key):
        raise HTTPException(429, "Juda ko'p urinish, 10 daqiqadan keyin qayta urin")
    u = db.user_by_email(email)
    if not u or not db.check_pw(data.password, u["pw_salt"], u["pw_hash"]):
        _fails.setdefault(key, []).append(time.time())
        raise HTTPException(401, "Email yoki parol noto'g'ri")
    set_cookie(response, db.new_session(u["id"]))
    return me_payload(u)


@app.post("/api/logout")
async def logout(request: Request, response: Response):
    token = request.cookies.get(COOKIE)
    if token:
        db.drop_session(token)
    response.delete_cookie(COOKIE)
    return {"ok": True}


@app.get("/api/me")
async def me(u=Depends(current_user)):
    return me_payload(u)


class SettingsIn(BaseModel):
    domla: Optional[Literal["h", "q"]] = None
    lang: Optional[Literal["en", "ru"]] = None
    daily: Optional[int] = Field(default=None, ge=1, le=100)
    monthly: Optional[int] = Field(default=None, ge=1, le=3000)
    notify_hour: Optional[int] = Field(default=None, ge=0, le=23)
    notify_on: Optional[bool] = None


@app.post("/api/settings")
async def settings(data: SettingsIn, u=Depends(current_user)):
    fields = {k: v for k, v in data.model_dump().items() if v is not None}
    if "notify_on" in fields:
        fields["notify_on"] = int(fields["notify_on"])
    db.update_user(u["id"], **fields)
    return me_payload(u)


# ---------- tariflar ----------
@app.get("/api/plans")
async def plans_list():
    return {"plans": plans.public(), "trial_days": config.TRIAL_DAYS, "pay": config.PAY_CONTACT}


class PlanIn(BaseModel):
    plan: Literal["free", "max", "ultra"]


@app.post("/api/plan/start")
async def plan_start(data: PlanIn, u=Depends(current_user)):
    if data.plan == "free":
        raise HTTPException(400, "Pullik tarifni toʻxtatish uchun admin bilan bogʻlaning")
    start_plan(u, data.plan)
    await notify.send_admin(f"💎 {u['name']} {u['surname']} ({u['email']}) {data.plan} sinovini boshladi")
    return me_payload(u)


# ---------- o'rganish ----------
def word_json(w):
    return {"id": w["id"], "word": w["word"], "ipa": w["ipa"], "translation": w["translation"],
            "mnemonic": w["mnemonic"], "example": w["example"]}


def _model(u):
    return config.model_for(db.effective_plan(u))


@app.get("/api/today")
async def today(u=Depends(current_user)):
    P = PLANS[db.effective_plan(u)]
    done = db.daily_done(u["id"])
    goal = min(u["daily"], P["words"])
    if done >= P["words"]:
        return {"word": None, "done": done, "goal": goal, "limit": True}
    w = db.next_new_word(u["id"], u["lang"])
    return {"word": word_json(w) if w else None, "done": done, "goal": goal, "limit": False}


class CheckIn(BaseModel):
    word_id: int
    sentence: str = Field(min_length=3, max_length=300)


@app.post("/api/check")
async def check(data: CheckIn, u=Depends(current_user)):
    P = PLANS[db.effective_plan(u)]
    w = db.get_word(data.word_id)
    if not w or w["status"] != "approved" or w["lang"] != u["lang"]:
        raise HTTPException(404, "So'z topilmadi")
    if db.daily_done(u["id"]) >= P["words"]:
        raise HTTPException(403, "Bugungi yangi so'z limiti tugadi. Ertaga davom etamiz yoki tarifni oshir 💎")
    if not db.use(u["id"], "ai", P["ai"]):
        raise HTTPException(429, "Bugungi AI limiti tugadi. Ertaga davom etamiz yoki tarifni oshir 💎")
    try:
        res = await ai.check_sentence(u["lang"], w["word"], w["translation"], data.sentence.strip(),
                                      u["domla"], _model(u))
    except ai.AIError as e:
        print("AI xato:", e)
        raise HTTPException(502, AI_BUSY)
    if res["ok"] and db.mark_learned(u["id"], w["id"]):
        db.touch_streak(u["id"])
    streak = db.effective_streak(db.user_by_id(u["id"]))
    return {"ok": res["ok"], "reply": res["reply"], "done": db.daily_done(u["id"]), "streak": streak}


@app.get("/api/review")
async def review(u=Depends(current_user)):
    w = db.due_word(u["id"])
    return {"word": word_json(w) if w else None, "due": db.due_count(u["id"])}


class ReviewIn(BaseModel):
    word_id: int
    remembered: bool


@app.post("/api/review")
async def review_post(data: ReviewIn, u=Depends(current_user)):
    if not db.review_result(u["id"], data.word_id, data.remembered):
        raise HTTPException(404, "So'z topilmadi")
    streak = db.touch_streak(u["id"]) if data.remembered else db.effective_streak(db.user_by_id(u["id"]))
    return {"due": db.due_count(u["id"]), "streak": streak}


@app.get("/api/notebook")
async def notebook(q: str = "", u=Depends(current_user)):
    return {"items": db.notebook(u["id"], q[:60])}


# ---------- test ----------
@app.get("/api/quiz")
async def quiz(u=Depends(current_user)):
    P = PLANS[db.effective_plan(u)]
    if not db.use(u["id"], "quiz", P["quiz"]):
        raise HTTPException(429, "Bugungi test limiti tugadi. Ertaga davom etamiz yoki tarifni oshir 💎")
    qs = db.quiz_questions(u["id"], u["lang"], P["quiz_len"])
    if len(qs) < 1:
        raise HTTPException(400, "Test uchun avval bir nechta so'z yodlash kerak (bazada kamida 4 ta so'z bo'lishi shart)")
    return {"questions": qs}


class QuizResult(BaseModel):
    wrong: list[int] = Field(default_factory=list, max_length=50)
    correct: int = Field(ge=0, le=50)


@app.post("/api/quiz/result")
async def quiz_result(data: QuizResult, u=Depends(current_user)):
    for wid in data.wrong:
        db.mark_wrong(u["id"], wid)
    streak = db.touch_streak(u["id"])
    return {"streak": streak}


# ---------- essay va gapirish ----------
class EssayIn(BaseModel):
    text: str = Field(min_length=30, max_length=2000)


@app.post("/api/essay")
async def essay(data: EssayIn, u=Depends(current_user)):
    P = PLANS[db.effective_plan(u)]
    if not db.use(u["id"], "essay", P["essay"]):
        raise HTTPException(429, "Bugungi essay limiti tugadi. Ertaga davom etamiz yoki tarifni oshir 💎")
    try:
        reply = await ai.check_essay(u["lang"], data.text.strip(), u["domla"], _model(u))
    except ai.AIError as e:
        print("AI xato:", e)
        raise HTTPException(502, AI_BUSY)
    return {"reply": reply}


class SpeakIn(BaseModel):
    text: str = Field(min_length=5, max_length=1200)
    topic: str = Field(default="", max_length=200)


@app.post("/api/speak")
async def speak(data: SpeakIn, u=Depends(current_user)):
    P = PLANS[db.effective_plan(u)]
    if P["speak"] == 0:
        raise HTTPException(403, "Gapirish mashqi Max va Ultra tariflarda 💎")
    if not db.use(u["id"], "speak", P["speak"]):
        raise HTTPException(429, "Bugungi gapirish limiti tugadi. Ertaga davom etamiz 🎤")
    try:
        reply = await ai.check_speaking(u["lang"], data.text.strip(), data.topic, u["domla"], _model(u))
    except ai.AIError as e:
        print("AI xato:", e)
        raise HTTPException(502, AI_BUSY)
    return {"reply": reply}


# ---------- reyting va faollik ----------
@app.get("/api/leaderboard")
async def leaderboard(u=Depends(current_user)):
    rows = db.leaderboard(200)
    top, rank = [], None
    for i, r in enumerate(rows, 1):
        if r["id"] == u["id"]:
            rank = i
        if i <= 20:
            top.append({"rank": i, "name": f"{r['name']} {r['surname'][:1]}.", "pts": r["pts"], "me": r["id"] == u["id"]})
    return {"top": top, "rank": rank}


@app.get("/api/activity")
async def activity(u=Depends(current_user)):
    return {"days": db.activity(u["id"], 28)}


@app.post("/api/telegram/link")
async def telegram_link(u=Depends(current_user)):
    if not config.USER_BOT_USERNAME:
        raise HTTPException(500, "Bot nomi sozlanmagan")
    code = db.new_link_code(u["id"])
    return {"url": f"https://t.me/{config.USER_BOT_USERNAME}?start={code}"}
