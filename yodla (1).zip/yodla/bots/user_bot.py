"""Foydalanuvchi boti: hisobni ulash va bildirishnomalar sozlamasi."""
import asyncio
import logging

from aiogram import Bot, Dispatcher, F, Router
from aiogram.filters import Command, CommandObject, CommandStart
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app import config, db

router = Router()
HOURS = [7, 8, 9, 12, 18, 20, 21, 22]


def settings_kb(u):
    rows = [[InlineKeyboardButton(text=("🔕 Bildirishnomani o'chirish" if u["notify_on"] else "🔔 Bildirishnomani yoqish"),
                                  callback_data="toggle")]]
    rows.append([InlineKeyboardButton(text=f"🕘 Vaqt: {u['notify_hour']:02d}:00", callback_data="time")])
    if config.BASE_URL.startswith("https://"):
        rows.append([InlineKeyboardButton(text="🌐 Saytni ochish", url=config.BASE_URL)])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def hours_kb():
    rows = [[InlineKeyboardButton(text=f"{h:02d}:00", callback_data=f"h:{h}") for h in HOURS[i:i + 4]]
            for i in range(0, len(HOURS), 4)]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def status_text(u):
    state = "yoqilgan 🔔" if u["notify_on"] else "o'chirilgan 🔕"
    return f"Bildirishnomalar {state}\nEslatma vaqti: {u['notify_hour']:02d}:00"


@router.message(CommandStart())
async def start(m: Message, command: CommandObject):
    if command.args:
        u = db.link_chat(command.args, m.chat.id)
        if not u:
            return await m.answer("Havola eskirgan 😅 Saytga kirib, sozlamalardan «Telegramni ulash» ni qayta bos.")
        greet = (f"Ulandi ✅ Xush kelibsan, {u['name']}! 😄\nEndi so'zlarni unutishga qo'ymayman."
                 if u["domla"] == "h" else f"Ulandi ✅ {u['name']}, endi bahona yo'q! 😤")
        return await m.answer(f"{greet}\n\n{status_text(u)}", reply_markup=settings_kb(u))
    u = db.user_by_chat(m.chat.id)
    if u:
        return await m.answer(f"Salom, {u['name']}! 👋\n\n{status_text(u)}", reply_markup=settings_kb(u))
    await m.answer("Salom! Men Yodla domlaman 🧠\n\nHisobingni ulash uchun saytga kir: "
                   f"{config.BASE_URL}\nSozlamalar ⚙️ → «Telegramni ulash» ni bos.")


@router.message(Command("stop"))
async def stop(m: Message):
    u = db.user_by_chat(m.chat.id)
    if u:
        db.update_user(u["id"], notify_on=0)
        await m.answer("Bildirishnomalar o'chirildi 🔕 Yoqish uchun /start ni bos.")


async def refresh(c: CallbackQuery):
    u = db.user_by_chat(c.message.chat.id)
    if not u:
        await c.answer("Hisob ulanmagan", show_alert=True)
        return None
    return u


@router.callback_query(F.data == "toggle")
async def toggle(c: CallbackQuery):
    u = await refresh(c)
    if u:
        db.update_user(u["id"], notify_on=0 if u["notify_on"] else 1)
        u = db.user_by_id(u["id"])
        await c.message.edit_text(status_text(u), reply_markup=settings_kb(u))
        await c.answer()


@router.callback_query(F.data == "time")
async def time_menu(c: CallbackQuery):
    if await refresh(c):
        await c.message.edit_text("Qaysi vaqtda eslatay? 🕘", reply_markup=hours_kb())
        await c.answer()


@router.callback_query(F.data.startswith("h:"))
async def set_hour(c: CallbackQuery):
    u = await refresh(c)
    if u:
        hour = int(c.data.split(":")[1])
        if hour in HOURS:
            db.update_user(u["id"], notify_hour=hour)
        u = db.user_by_id(u["id"])
        await c.message.edit_text(status_text(u), reply_markup=settings_kb(u))
        await c.answer("Saqlandi ✅")


async def main():
    logging.basicConfig(level=logging.INFO)
    if not config.USER_BOT_TOKEN:
        raise SystemExit("USER_BOT_TOKEN .env faylida yo'q")
    db.init()
    bot = Bot(config.USER_BOT_TOKEN)
    dp = Dispatcher()
    dp.include_router(router)
    print("Foydalanuvchi boti ishga tushdi ✅")
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
