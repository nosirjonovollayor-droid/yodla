"""Telegramga bildirishnoma yuborish va kunlik eslatma rejalashtiruvchisi."""
import asyncio

import httpx

from . import config, db


async def _send(token, chat_id, text, button=None):
    if not token:
        return False
    payload = {"chat_id": chat_id, "text": text}
    # Telegram faqat https havolali tugmani qabul qiladi
    if button and config.BASE_URL.startswith("https://"):
        payload["reply_markup"] = {"inline_keyboard": [[{"text": button[0], "url": button[1]}]]}
    try:
        async with httpx.AsyncClient(timeout=15) as c:
            r = await c.post(f"https://api.telegram.org/bot{token}/sendMessage", json=payload)
        return r.status_code == 200
    except httpx.HTTPError:
        return False


async def send_user(chat_id, text, with_button=True):
    return await _send(config.USER_BOT_TOKEN, chat_id, text,
                       ("🌐 Yodlashni boshlash", config.BASE_URL) if with_button else None)


async def send_admin(text):
    for aid in config.ADMIN_IDS:
        await _send(config.ADMIN_BOT_TOKEN, aid, text)


def daily_text(u, due):
    name = u["name"]
    extra = f"\n🔁 Takrorlash kerak: {due} ta so'z" if due else ""
    if u["domla"] == "q":
        return f"{name}, vaqt bo'ldi! 😤 Bugungi so'zlar kutyapti. Bahona yo'q!{extra}"
    return f"Salom, {name}! 😄 Bugungi so'zlar tayyor, yodlaymizmi?{extra}"


def nudge_text(u):
    name = u["name"]
    if u["domla"] == "q":
        return f"{name}! Bugun hali bitta ham so'z yodlamading. Seriya uzilishiga oz qoldi. Hozir kir! 😤"
    return f"Voy, {name}, seriyang uzilib qoladi 😏 Bugun hali bitta ham so'z yodlamading!"


async def tick():
    hour, day = db.now().hour, db.today()
    for u in db.users_with_tg():
        if hour == u["notify_hour"] and u["last_notified"] != day:
            db.update_user(u["id"], last_notified=day)  # avval belgilaymiz, takror yuborilmasin
            await send_user(u["tg_chat_id"], daily_text(u, db.due_count(u["id"])))
        elif (hour == 20 and u["notify_hour"] != 20 and u["last_nudge"] != day
              and db.daily_done(u["id"]) == 0 and db.effective_streak(u) > 0):
            db.update_user(u["id"], last_nudge=day)
            await send_user(u["tg_chat_id"], nudge_text(u))


async def loop():
    while True:
        try:
            await tick()
        except Exception as e:  # server yiqilmasin
            print("Bildirishnoma xatosi:", e)
        await asyncio.sleep(60)
