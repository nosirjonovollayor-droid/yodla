"""Ma'lumotlar bazasi (SQLite). Hamma narsa shu yerda saqlanadi."""
import hashlib
import hmac
import secrets
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

from . import config

# Takrorlash oraliqlari (kun). So'z yodlangach 1 kundan keyin so'raladi.
INTERVALS = [1, 2, 4, 7, 15, 30, 60]
DONE_STAGE = 4  # shu bosqichdan boshlab "yodlangan" hisoblanadi
SESSION_DAYS = 30

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL, surname TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  pw_salt TEXT NOT NULL, pw_hash TEXT NOT NULL,
  lang TEXT NOT NULL DEFAULT 'en',
  daily INTEGER NOT NULL DEFAULT 10, monthly INTEGER NOT NULL DEFAULT 300,
  domla TEXT NOT NULL DEFAULT 'h',
  streak INTEGER NOT NULL DEFAULT 0, last_active TEXT,
  notify_hour INTEGER NOT NULL DEFAULT 9, notify_on INTEGER NOT NULL DEFAULT 1,
  tg_chat_id INTEGER, tg_code TEXT,
  last_notified TEXT, last_nudge TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions(
  token TEXT PRIMARY KEY, user_id INTEGER NOT NULL, created_at TEXT NOT NULL,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS words(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  lang TEXT NOT NULL, word TEXT NOT NULL, translation TEXT NOT NULL,
  ipa TEXT NOT NULL DEFAULT '', mnemonic TEXT NOT NULL DEFAULT '', example TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS words_uq ON words(lang, lower(word));
CREATE TABLE IF NOT EXISTS progress(
  user_id INTEGER NOT NULL, word_id INTEGER NOT NULL,
  stage INTEGER NOT NULL DEFAULT 0, next_review TEXT NOT NULL, learned_at TEXT NOT NULL,
  PRIMARY KEY(user_id, word_id),
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY(word_id) REFERENCES words(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS daily(
  user_id INTEGER NOT NULL, day TEXT NOT NULL, count INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(user_id, day)
);
CREATE TABLE IF NOT EXISTS usage(
  user_id INTEGER NOT NULL, day TEXT NOT NULL, kind TEXT NOT NULL, n INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(user_id, day, kind)
);
"""


# ---------- umumiy yordamchilar ----------
def now():
    return datetime.now(ZoneInfo(config.TIMEZONE))


def today():
    return now().date().isoformat()


def day_plus(n):
    return (now().date() + timedelta(days=n)).isoformat()


@contextmanager
def conn():
    Path(config.DB_PATH).parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(config.DB_PATH, timeout=15)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    try:
        yield c
        c.commit()
    finally:
        c.close()


def init():
    with conn() as c:
        c.execute("PRAGMA journal_mode=WAL")
        c.executescript(SCHEMA)
        cols = {r["name"] for r in c.execute("PRAGMA table_info(users)")}
        for name, ddl in [("plan", "TEXT NOT NULL DEFAULT 'free'"), ("plan_until", "TEXT"),
                          ("trial_used", "INTEGER NOT NULL DEFAULT 0")]:
            if name not in cols:  # eski bazani yangilash
                c.execute(f"ALTER TABLE users ADD COLUMN {name} {ddl}")


# ---------- parol ----------
def hash_pw(password, salt=None):
    salt = salt or secrets.token_hex(16)
    h = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), 200_000).hex()
    return salt, h


def check_pw(password, salt, expected):
    return hmac.compare_digest(hash_pw(password, salt)[1], expected)


# ---------- foydalanuvchilar ----------
def create_user(name, surname, email, password, lang, daily, monthly, domla):
    salt, h = hash_pw(password)
    with conn() as c:
        cur = c.execute(
            "INSERT INTO users(name,surname,email,pw_salt,pw_hash,lang,daily,monthly,domla,created_at)"
            " VALUES(?,?,?,?,?,?,?,?,?,?)",
            (name, surname, email.lower(), salt, h, lang, daily, monthly, domla, now().isoformat()),
        )
        return cur.lastrowid


def user_by_email(email):
    with conn() as c:
        return c.execute("SELECT * FROM users WHERE email=?", (email.lower(),)).fetchone()


def user_by_id(uid):
    with conn() as c:
        return c.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()


def user_by_chat(chat_id):
    with conn() as c:
        return c.execute("SELECT * FROM users WHERE tg_chat_id=?", (chat_id,)).fetchone()


_ALLOWED = {"name", "surname", "lang", "daily", "monthly", "domla", "streak", "last_active",
            "notify_hour", "notify_on", "tg_chat_id", "tg_code", "last_notified", "last_nudge",
            "plan", "plan_until", "trial_used"}


def update_user(uid, **fields):
    fields = {k: v for k, v in fields.items() if k in _ALLOWED}
    if not fields:
        return
    sets = ",".join(f"{k}=?" for k in fields)
    with conn() as c:
        c.execute(f"UPDATE users SET {sets} WHERE id=?", (*fields.values(), uid))


def effective_streak(u):
    return u["streak"] if u["last_active"] in (today(), day_plus(-1)) else 0


def touch_streak(uid):
    """Foydalanuvchi bugun faol bo'ldi: seriyani yangilaydi."""
    u = user_by_id(uid)
    t = today()
    if u["last_active"] == t:
        return u["streak"]
    streak = u["streak"] + 1 if u["last_active"] == day_plus(-1) else 1
    update_user(uid, streak=streak, last_active=t)
    return streak


# ---------- sessiyalar ----------
def new_session(uid):
    token = secrets.token_urlsafe(32)
    with conn() as c:
        c.execute("INSERT INTO sessions(token,user_id,created_at) VALUES(?,?,?)",
                  (token, uid, now().isoformat()))
    return token


def user_by_token(token):
    with conn() as c:
        s = c.execute("SELECT * FROM sessions WHERE token=?", (token,)).fetchone()
        if not s:
            return None
        created = datetime.fromisoformat(s["created_at"])
        if now() - created > timedelta(days=SESSION_DAYS):
            c.execute("DELETE FROM sessions WHERE token=?", (token,))
            return None
        return c.execute("SELECT * FROM users WHERE id=?", (s["user_id"],)).fetchone()


def drop_session(token):
    with conn() as c:
        c.execute("DELETE FROM sessions WHERE token=?", (token,))


# ---------- so'zlar ----------
def add_word(lang, word, translation, ipa="", mnemonic="", example="", status="pending"):
    with conn() as c:
        cur = c.execute(
            "INSERT INTO words(lang,word,translation,ipa,mnemonic,example,status,created_at)"
            " VALUES(?,?,?,?,?,?,?,?)",
            (lang, word, translation, ipa, mnemonic, example, status, now().isoformat()),
        )
        return cur.lastrowid


def word_exists(lang, word):
    with conn() as c:
        return c.execute("SELECT id FROM words WHERE lang=? AND lower(word)=lower(?)",
                         (lang, word)).fetchone() is not None


def get_word(wid):
    with conn() as c:
        return c.execute("SELECT * FROM words WHERE id=?", (wid,)).fetchone()


def update_word(wid, **fields):
    allowed = {"word", "translation", "ipa", "mnemonic", "example", "status"}
    fields = {k: v for k, v in fields.items() if k in allowed}
    if not fields:
        return
    sets = ",".join(f"{k}=?" for k in fields)
    with conn() as c:
        c.execute(f"UPDATE words SET {sets} WHERE id=?", (*fields.values(), wid))


def delete_word(wid):
    with conn() as c:
        c.execute("DELETE FROM words WHERE id=?", (wid,))


def list_words(lang, status, limit=30, offset=0):
    with conn() as c:
        return c.execute(
            "SELECT * FROM words WHERE lang=? AND status=? ORDER BY id DESC LIMIT ? OFFSET ?",
            (lang, status, limit, offset)).fetchall()


def first_pending(lang):
    with conn() as c:
        return c.execute("SELECT * FROM words WHERE lang=? AND status='pending' ORDER BY id LIMIT 1",
                         (lang,)).fetchone()


def count_words(lang, status):
    with conn() as c:
        return c.execute("SELECT COUNT(*) FROM words WHERE lang=? AND status=?",
                         (lang, status)).fetchone()[0]


def approve_all_pending(lang):
    with conn() as c:
        cur = c.execute("UPDATE words SET status='approved' WHERE lang=? AND status='pending' AND mnemonic<>''",
                        (lang,))
        return cur.rowcount


# ---------- o'rganish ----------
def next_new_word(uid, lang):
    with conn() as c:
        return c.execute(
            "SELECT * FROM words w WHERE w.lang=? AND w.status='approved' AND NOT EXISTS"
            " (SELECT 1 FROM progress p WHERE p.user_id=? AND p.word_id=w.id) ORDER BY w.id LIMIT 1",
            (lang, uid)).fetchone()


def daily_done(uid):
    with conn() as c:
        r = c.execute("SELECT count FROM daily WHERE user_id=? AND day=?", (uid, today())).fetchone()
        return r["count"] if r else 0


def mark_learned(uid, wid):
    """Birinchi marta yodlansa True qaytaradi."""
    with conn() as c:
        if c.execute("SELECT 1 FROM progress WHERE user_id=? AND word_id=?", (uid, wid)).fetchone():
            return False
        c.execute("INSERT INTO progress(user_id,word_id,stage,next_review,learned_at) VALUES(?,?,0,?,?)",
                  (uid, wid, day_plus(INTERVALS[0]), now().isoformat()))
        c.execute("INSERT INTO daily(user_id,day,count) VALUES(?,?,1)"
                  " ON CONFLICT(user_id,day) DO UPDATE SET count=count+1", (uid, today()))
    return True


def due_count(uid):
    with conn() as c:
        return c.execute(
            "SELECT COUNT(*) FROM progress p JOIN words w ON w.id=p.word_id"
            " WHERE p.user_id=? AND p.next_review<=? AND w.status='approved'",
            (uid, today())).fetchone()[0]


def due_word(uid):
    with conn() as c:
        return c.execute(
            "SELECT w.* FROM progress p JOIN words w ON w.id=p.word_id"
            " WHERE p.user_id=? AND p.next_review<=? AND w.status='approved'"
            " ORDER BY p.next_review, p.word_id LIMIT 1", (uid, today())).fetchone()


def review_result(uid, wid, remembered):
    with conn() as c:
        p = c.execute("SELECT stage FROM progress WHERE user_id=? AND word_id=?", (uid, wid)).fetchone()
        if not p:
            return False
        if remembered:
            stage = min(p["stage"] + 1, len(INTERVALS) - 1)
            nxt = day_plus(INTERVALS[stage])
        else:
            stage, nxt = 0, day_plus(1)
        c.execute("UPDATE progress SET stage=?, next_review=? WHERE user_id=? AND word_id=?",
                  (stage, nxt, uid, wid))
    return True


def notebook(uid, q=""):
    q = (q or "").lower().replace("%", "").replace("_", "").strip()
    like = f"%{q}%"
    with conn() as c:
        rows = c.execute(
            "SELECT w.word, w.translation, p.stage FROM progress p JOIN words w ON w.id=p.word_id"
            " WHERE p.user_id=? AND (lower(w.word) LIKE ? OR lower(w.translation) LIKE ?)"
            " ORDER BY p.learned_at DESC LIMIT 200", (uid, like, like)).fetchall()
    return [{"word": r["word"], "translation": r["translation"],
             "status": "yodlangan" if r["stage"] >= DONE_STAGE else "takrorlash"} for r in rows]


# ---------- tarif va limitlar ----------
def effective_plan(u):
    if u["plan"] != "free" and u["plan_until"] and u["plan_until"] >= today():
        return u["plan"]
    return "free"


def used(uid, kind):
    with conn() as c:
        r = c.execute("SELECT n FROM usage WHERE user_id=? AND day=? AND kind=?", (uid, today(), kind)).fetchone()
        return r["n"] if r else 0


def use(uid, kind, limit):
    """Limit tugamagan bo'lsa 1 ta sarflaydi va True qaytaradi."""
    with conn() as c:
        r = c.execute("SELECT n FROM usage WHERE user_id=? AND day=? AND kind=?", (uid, today(), kind)).fetchone()
        if (r["n"] if r else 0) >= limit:
            return False
        c.execute("INSERT INTO usage(user_id,day,kind,n) VALUES(?,?,?,1)"
                  " ON CONFLICT(user_id,day,kind) DO UPDATE SET n=n+1", (uid, today(), kind))
    return True


def grant_plan(uid, plan, days):
    u = user_by_id(uid)
    base = u["plan_until"] if effective_plan(u) == plan else today()
    start = max(base, today())
    until = (datetime.fromisoformat(start) + timedelta(days=days)).date().isoformat()
    update_user(uid, plan=plan, plan_until=until)
    return until


# ---------- statistika va reyting ----------
def total_learned(uid):
    with conn() as c:
        return c.execute("SELECT COUNT(*) FROM progress WHERE user_id=?", (uid,)).fetchone()[0]


def activity(uid, days=28):
    start = day_plus(-(days - 1))
    with conn() as c:
        rows = c.execute("SELECT day,count FROM daily WHERE user_id=? AND day>=?", (uid, start)).fetchall()
    m = {r["day"]: r["count"] for r in rows}
    return [{"day": day_plus(-i), "count": m.get(day_plus(-i), 0)} for i in range(days - 1, -1, -1)]


def leaderboard(limit=20):
    with conn() as c:
        return c.execute(
            "SELECT u.id,u.name,u.surname,SUM(d.count) AS pts FROM daily d JOIN users u ON u.id=d.user_id"
            " WHERE d.day>=? GROUP BY u.id HAVING pts>0 ORDER BY pts DESC, u.id LIMIT ?",
            (day_plus(-6), limit)).fetchall()


def quiz_questions(uid, lang, n):
    import random
    with conn() as c:
        learned = c.execute(
            "SELECT w.* FROM progress p JOIN words w ON w.id=p.word_id"
            " WHERE p.user_id=? AND w.lang=? AND w.status='approved' ORDER BY RANDOM() LIMIT ?",
            (uid, lang, n)).fetchall()
        pool = [r["translation"] for r in c.execute(
            "SELECT DISTINCT translation FROM words WHERE lang=? AND status='approved'", (lang,))]
    qs = []
    for w in learned:
        others = [t for t in pool if t.lower() != w["translation"].lower()]
        if len(others) < 3:
            continue
        opts = random.sample(others, 3) + [w["translation"]]
        random.shuffle(opts)
        qs.append({"word_id": w["id"], "q": w["word"], "ipa": w["ipa"], "options": opts,
                   "answer": opts.index(w["translation"])})
    return qs


def mark_wrong(uid, wid):
    with conn() as c:
        c.execute("UPDATE progress SET next_review=? WHERE user_id=? AND word_id=?", (today(), uid, wid))


# ---------- Telegram ulash ----------
def new_link_code(uid):
    code = secrets.token_urlsafe(8)
    update_user(uid, tg_code=code)
    return code


def link_chat(code, chat_id):
    with conn() as c:
        u = c.execute("SELECT * FROM users WHERE tg_code=?", (code,)).fetchone()
        if not u:
            return None
        c.execute("UPDATE users SET tg_chat_id=NULL WHERE tg_chat_id=?", (chat_id,))
        c.execute("UPDATE users SET tg_chat_id=?, tg_code=NULL WHERE id=?", (chat_id, u["id"]))
        return c.execute("SELECT * FROM users WHERE id=?", (u["id"],)).fetchone()


def users_with_tg():
    with conn() as c:
        return c.execute("SELECT * FROM users WHERE tg_chat_id IS NOT NULL AND notify_on=1").fetchall()


# ---------- statistika (admin uchun) ----------
def stats():
    with conn() as c:
        users = c.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        linked = c.execute("SELECT COUNT(*) FROM users WHERE tg_chat_id IS NOT NULL").fetchone()[0]
        learned = c.execute("SELECT COALESCE(SUM(count),0) FROM daily WHERE day=?", (today(),)).fetchone()[0]
        pl = {r["plan"]: r["n"] for r in c.execute(
            "SELECT plan, COUNT(*) AS n FROM users WHERE plan<>'free' AND plan_until>=? GROUP BY plan", (today(),))}
    return {"users": users, "linked": linked, "learned_today": learned, "plans": pl,
            "en_ok": count_words("en", "approved"), "en_pending": count_words("en", "pending"),
            "ru_ok": count_words("ru", "approved"), "ru_pending": count_words("ru", "pending")}
