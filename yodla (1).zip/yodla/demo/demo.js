/* Faqat dizaynni serversiz ko'rsatish uchun: soxta API (haqiqiy ma'lumot saqlamaydi) */
window.YODLA_DEMO = true;
(() => {
const WORDS = {
  en: [['reluctant','ri-LAK-tant','istamaydigan','Dushanba, soat 6: koʻrpada «relyuktant» yotibsan 😴','I was reluctant to wake up.'],
       ['aberration','ab-er-AY-shn','gʻalati holat','ABeRni RATIONi yoʻqolibdi 🤯','It was an aberration.'],
       ['meticulous','me-TIK-yu-lus','juda puxta','Metrni yuz marta tekshiradigan usta 📏','She is meticulous.'],
       ['ubiquitous','yu-BIK-wi-tus','hamma joyda boʻladigan','«Yubik-vitas»: hamma joyda Uber 🚕','Phones are ubiquitous.'],
       ['serene','se-REEN','sokin, tinch','«Sirin» kol: tinch, sokin 🌊','The lake was serene.'],
       ['vivid','VI-vid','yorqin','«Vivid» = viv-id: videoning yorqin rangi 🎨','She has vivid dreams.']],
  ru: [['упрямый','up-RYA-mij','oʻjar','«Upryamyj» — «oʻrmon-yaxshi» emas, oʻjar eshak 🫏','Он очень упрямый.'],
       ['привычка','pri-VICH-ka','odat','«Privichka» — «privichka» qilib qoʻyding, odat boʻldi 🔁','Это моя привычка.'],
       ['радость','RA-dost','quvonch','«Radost» — radio eshitib quvonding 📻','Какая радость!']]
};
const PLANS = [
  {id:'free',name:'Free',month:0,year:0,popular:false,features:['Kuniga 5 ta yangi soʻz','AI domla gap tekshiruvi: 10 ta/kun','Essay tekshirish: 1 ta/kun','Test: kuniga 1 marta (5 savol)','Gapirish mashqi: yoʻq','Cheksiz takrorlash, reyting va yutuqlar']},
  {id:'max',name:'Max',month:29000,year:290000,popular:true,features:['Kuniga 20 ta yangi soʻz','AI domla gap tekshiruvi: 60 ta/kun','Essay tekshirish: 5 ta/kun','Test: kuniga 10 marta (10 savol)','Gapirish mashqi: 5 ta/kun','Cheksiz takrorlash, reyting va yutuqlar']},
  {id:'ultra',name:'Ultra',month:59000,year:590000,popular:false,features:['Deyarli cheksiz yangi soʻz','AI domla gap tekshiruvi: 200 ta/kun','Essay tekshirish: 20 ta/kun','Test: cheksiz (15 savol)','Gapirish mashqi: 30 ta/kun','Cheksiz takrorlash, reyting va yutuqlar','Kuchliroq AI model','Ustuvor yordam']}
];
const LIM = {free:{words:5,ai:10,essay:1,speak:0,quiz:1}, max:{words:20,ai:60,essay:5,speak:5,quiz:10}, ultra:{words:100,ai:200,essay:20,speak:30,quiz:99}};
let me = null, learned = [], used = {ai:0,essay:0,speak:0,quiz:0};
const day = n => { const d = new Date(); d.setDate(d.getDate() + n); return d.toISOString().slice(0, 10); };
const err = (status, msg) => { throw {status, msg}; };
const mkMe = (o = {}) => me = Object.assign({name:'Ali',surname:'Valiyev',email:'ali@gmail.com',lang:'en',daily:10,monthly:300,domla:'h',streak:4,done:0,total:0,
  notify_hour:9,notify_on:true,tg:false,bot:'yodla_bot',plan:'free',plan_until:null,trial_used:false,pay:'@yodla_admin'}, o);
const pay = () => { const L = LIM[me.plan]; me.daily = Math.min(me.daily, L.words); me.total = learned.length;
  me.limits = {words:L.words,ai:L.ai,ai_left:L.ai-used.ai,essay:L.essay,essay_left:L.essay-used.essay,speak:L.speak,speak_left:L.speak-used.speak,quiz:L.quiz,quiz_left:L.quiz-used.quiz}; return {...me}; };
const list = () => WORDS[me.lang].map((w, i) => ({id:(me.lang === 'en' ? 100 : 200) + i, word:w[0], ipa:w[1], translation:w[2], mnemonic:w[3], example:w[4]}));
const startPlan = p => { if (p !== 'free') { if (me.plan !== 'free' || me.trial_used) err(402, 'Pullik tarif uchun @yodla_admin ga yozing, tez faollashtirib beramiz'); me.plan = p; me.plan_until = day(7); me.trial_used = true; } };
window.mockApi = (path, method, b) => new Promise((res, rej) => setTimeout(() => { try { res(route(path, method, b || {})); } catch (e) { rej(e); } }, 220));
function route(path, method, b) {
  const [p, qs] = path.split('?');
  if (p === '/plans') return {plans:PLANS, trial_days:7, pay:'@yodla_admin'};
  if (p === '/register') { learned = []; used = {ai:0,essay:0,speak:0,quiz:0}; mkMe({name:b.name,surname:b.surname,email:b.mail||b.email,lang:b.lang,daily:b.daily,monthly:b.monthly,domla:b.domla,streak:0}); startPlan(b.plan); return pay(); }
  if (p === '/login') { if (!me) mkMe(); return pay(); }
  if (!me) err(401, 'Kirish kerak');
  if (p === '/me') return pay();
  if (p === '/logout') { me = null; return {ok:true}; }
  if (p === '/settings') { Object.assign(me, b); return pay(); }
  if (p === '/plan/start') { startPlan(b.plan); return pay(); }
  if (p === '/today') { const L = LIM[me.plan], w = list().find(x => !learned.includes(x.id)); const done = learned.length;
    return {word: done >= L.words ? null : w || null, done, goal: Math.min(me.daily, L.words), limit: done >= L.words}; }
  if (p === '/check') { const w = list().find(x => x.id === b.word_id); if (used.ai >= LIM[me.plan].ai) err(429, 'Bugungi AI limiti tugadi 💎'); used.ai++;
    const ok = b.sentence.toLowerCase().includes(w.word.toLowerCase());
    if (ok && !learned.includes(w.id)) { learned.push(w.id); me.streak = Math.max(me.streak, 1); }
    return {ok, reply: ok ? (me.domla === 'h' ? 'Barakalla! Gaping zoʻr chiqdi 😎 Keyingi soʻzga oʻtamiz!' : 'Toʻgʻri. Toʻxtama, keyingisi! 💪')
      : (me.domla === 'h' ? 'Soʻzning oʻzi qani? Gapda yoʻq-ku 😂 Yana urin!' : 'Soʻz ishlatilmagan! Qaytadan! 😤'), done: learned.length, streak: me.streak}; }
  if (p === '/review' && method === 'POST') return {due: 0, streak: me.streak};
  if (p === '/review') { const w = list().find(x => learned.includes(x.id)); return {word: w || null, due: learned.length}; }
  if (p === '/notebook') { const q = (new URLSearchParams(qs).get('q') || '').toLowerCase();
    return {items: list().filter(w => learned.includes(w.id) && (w.word.toLowerCase().includes(q) || w.translation.toLowerCase().includes(q))).map((w, i) => ({word:w.word, translation:w.translation, status: i % 2 ? 'yodlangan' : 'takrorlash'}))}; }
  if (p === '/quiz') { if (used.quiz >= LIM[me.plan].quiz) err(429, 'Bugungi test limiti tugadi 💎'); const L = list(); const got = L.filter(w => learned.includes(w.id));
    if (!got.length) err(400, 'Test uchun avval bir nechta soʻz yodla'); used.quiz++;
    return {questions: got.map(w => { const o = [w.translation, ...L.filter(x => x.id !== w.id).slice(0, 3).map(x => x.translation)].sort(() => Math.random() - .5); return {word_id:w.id, q:w.word, ipa:w.ipa, options:o, answer:o.indexOf(w.translation)}; })}; }
  if (p === '/quiz/result') return {streak: me.streak};
  if (p === '/essay') { if (used.essay >= LIM[me.plan].essay) err(429, 'Bugungi essay limiti tugadi 💎'); used.essay++;
    return {reply: '1) «I goes» -> «I go»: birinchi shaxsda -es qoʻshilmaydi.\n2) «more better» -> «better»: ikki marta qoʻshib boʻlmaydi.\n\nTuzatilgan variant: «I go to school every day.»\n\nUmumiy fikr: gaplaring tushunarli, taxminiy daraja A2 😉 (bu namuna javob)'}; }
  if (p === '/speak') { if (!LIM[me.plan].speak) err(403, 'Gapirish mashqi Max va Ultra tariflarda 💎'); used.speak++; return {reply: '1) «I am like football» -> «I like football»\n\nNaturalroq: «I really like football and play it every weekend.»\n\nMaslahat: gaplarni «because» bilan uzaytir. Taxminiy daraja A2 (bu namuna javob)'}; }
  if (p === '/leaderboard') return {top:[{rank:1,name:'Dilnoza K.',pts:42,me:false},{rank:2,name:'Jasur M.',pts:35,me:false},{rank:3,name:me.name + ' ' + me.surname[0] + '.',pts:learned.length + 12,me:true},{rank:4,name:'Madina A.',pts:9,me:false}], rank:3};
  if (p === '/activity') return {days: Array.from({length:28}, (_, i) => ({day:day(i - 27), count: i > 15 && i % 3 ? [2,5,9,0,4,7][i % 6] : 0}))};
  if (p === '/telegram/link') { setTimeout(() => { me.tg = true; }, 4000); return {url:'https://t.me/yodla_bot'}; }
  err(404, 'Topilmadi');
}
})();
