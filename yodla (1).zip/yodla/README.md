# Yodla: soʻzni kulib yodla 🧠

Sayt + AI (OpenRouter) + ikkita Telegram bot, hammasi bitta baza bilan ishlaydi.
Tariflar: **Free / Max / Ultra**.

## Papkalar
- `app/` server: `main.py` (sayt va API), `db.py` (baza), `ai.py` (AI), `plans.py` (**tarif narxi va limitlari**), `notify.py` (eslatmalar)
- `bots/admin_bot.py`: admin bot (soʻz qoʻshish, tarif berish)
- `bots/user_bot.py`: foydalanuvchi boti (hisobni ulash, eslatma vaqti)
- `static/`: sayt (`index.html`, `style.css`, `app.js`, `logo.png`)
- `demo/demo.js`: faqat dizaynni serversiz koʻrsatish uchun soxta API (ishlatilmaydi)

## 1. Oʻrnatish (bir marta)
Python 3.11 yoki yangisi kerak. Loyiha papkasida terminal oching:

```
python -m venv venv
venv\Scripts\activate          (Mac/Linux: source venv/bin/activate)
pip install -r requirements.txt
```

## 2. Sozlash
`.env.example` dan nusxa olib, nomini `.env` qiling va toʻldiring:
- `USER_BOT_TOKEN`, `USER_BOT_USERNAME` (@ belgisiz), `ADMIN_BOT_TOKEN`: @BotFather bergan maʼlumotlar
- `ADMIN_IDS`: oʻzingizning Telegram ID'ingiz (@userinfobot)
- `OPENROUTER_API_KEY` va `OPENROUTER_MODEL` (model nomini openrouter.ai/models dan tekshiring)
- `PAY_CONTACT`: toʻlov uchun foydalanuvchilar yozadigan Telegram manzilingiz

`.env` faylini hech kimga yubormang.

## 3. Ishga tushirish (3 ta alohida terminal, hammasida `venv` yoqilgan)
```
uvicorn app.main:app --reload
python -m bots.admin_bot
python -m bots.user_bot
```
Sayt: http://localhost:8000

## 4. Tariflar qanday ishlaydi
- Narx va limitlar `app/plans.py` da (Free 0, Max 29 000, Ultra 59 000 soʻm/oy). Bu **taklif qilingan** narxlar, oʻzingizga moslab oʻzgartiring.
- Max/Ultra tanlagan yangi foydalanuvchiga **7 kunlik bepul sinov** beriladi (bir marta).
- Hozircha **avtomatik toʻlov yoʻq**. Foydalanuvchi `PAY_CONTACT` ga yozadi, karta orqali toʻlaydi, siz admin botda tarif berasiz:
  `/grant ali@mail.com max 30`  (30 kunga Max). Muddat tugagach u oʻzi Free'ga qaytadi.
- Click/Payme ulash uchun ularda merchant hisob kerak, keyingi bosqichda qoʻshamiz.

## 5. Birinchi sinov
1. Admin botda `/start` → 🇬🇧 Ingliz tili → ➕ Soʻz qoʻshish → soʻz va tarjima → AI mnemonika → ✅ Tasdiqlash. Testlar uchun kamida 4-5 ta soʻz qoʻshing.
2. Saytda roʻyxatdan oʻting → soʻz yodlang → Takrorlash, Test, Essay, Reyting boʻlimlarini koʻring.
3. Sozlamalar ⚙️ → «Telegramni ulash» → botda Start.

## Muhim
- Telegram tugmalardagi havola faqat **https** manzilda ishlaydi (kompyuterda sinaganda tugma chiqmasligi normal).
- Internetga chiqarganda `BASE_URL=https://...` va `COOKIE_SECURE=1` qiling.
- Gapirish mashqi brauzerning ovoz tanish imkoniyatidan foydalanadi (Chrome/Edge/Safari yaxshi ishlaydi, Firefox'da ishlamaydi), shuning uchun matn yozib yuborish ham bor.
- AI nutqni **matn** sifatida tekshiradi, talaffuzni baholamaydi.
- Bazani zaxiralash: `data/yodla.db` faylini nusxalang. Eski bazang bor boʻlsa, server uni oʻzi yangilaydi.
