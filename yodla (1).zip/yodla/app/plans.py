"""Tariflar. Narx va limitlarni faqat shu yerda o'zgartirasiz."""

PLANS = {
    "free": {"name": "Free", "month": 0, "year": 0,
             "words": 5, "ai": 10, "essay": 1, "speak": 0, "quiz": 1, "quiz_len": 5},
    "max": {"name": "Max", "month": 29000, "year": 290000,
            "words": 20, "ai": 60, "essay": 5, "speak": 5, "quiz": 10, "quiz_len": 10},
    "ultra": {"name": "Ultra", "month": 59000, "year": 590000,
              "words": 100, "ai": 200, "essay": 20, "speak": 30, "quiz": 99, "quiz_len": 15},
}


def features(pid):
    p = PLANS[pid]
    f = [f"Kuniga {p['words']} ta yangi so‘z" if pid != "ultra" else "Deyarli cheksiz yangi so‘z",
         f"AI domla gap tekshiruvi: {p['ai']} ta/kun",
         f"Essay tekshirish: {p['essay']} ta/kun",
         f"Test: kuniga {p['quiz']} marta ({p['quiz_len']} savol)" if pid != "ultra"
         else f"Test: cheksiz ({p['quiz_len']} savol)"]
    f.append(f"Gapirish mashqi: {p['speak']} ta/kun" if p["speak"] else "Gapirish mashqi: yo‘q")
    f.append("Cheksiz takrorlash, reyting va yutuqlar")
    if pid == "ultra":
        f += ["Kuchliroq AI model", "Ustuvor yordam"]
    return f


def public():
    return [{"id": k, "name": v["name"], "month": v["month"], "year": v["year"],
             "popular": k == "max", "features": features(k)} for k, v in PLANS.items()]
