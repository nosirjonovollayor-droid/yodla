"""Admin bot: so'z va tarjima qo'shish (Ingliz / Rus bo'limlari)."""
import asyncio
import logging
import re

from aiogram import Bot, Dispatcher, F, Router
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app import ai, config, db, notify

router = Router()
router.message.filter(F.from_user.id.in_(config.ADMIN_IDS))
router.callback_query.filter(F.from_user.id.in_(config.ADMIN_IDS))

FLAG = {"en": "🇬🇧 Ingliz tili", "ru": "🇷🇺 Rus tili"}
SEP_SPACED = re.compile(r"\s+[-–—=:]\s+")


def parse_line(line):
    """'so'z - tarjima' qatorini (so'z, tarjima) ga ajratadi."""
    line = line.strip()
    m = SEP_SPACED.search(line) or re.search(r"\s*[=:–—]\s*", line) or re.search(r"\s*-\s*", line)
    if not m:
        return None
    word, tr = line[:m.start()].strip(), line[m.end():].strip()
    return (word, tr) if word and tr else None


class Add(StatesGroup):
    word = State()
    translation = State()


class Bulk(StatesGroup):
    text = State()


def kb(*rows):
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text=t, callback_data=d) for t, d in row]
                                                 for row in rows if row])


def main_kb():
    return kb([(FLAG["en"], "lang:en")], [(FLAG["ru"], "lang:ru")], [("📊 Statistika", "stats")])


def lang_kb(lang):
    return kb([("➕ So'z qo'shish", f"add:{lang}")], [("📥 Ko'plab qo'shish", f"bulk:{lang}")],
              [("⏳ Tasdiq kutayotganlar", f"pend:{lang}")], [("📋 Ro'yxat", f"list:{lang}")],
              [("⬅️ Orqaga", "home")])


def lang_text(lang):
    return (f"{FLAG[lang]}\n\n✅ Tasdiqlangan: {db.count_words(lang, 'approved')}\n"
            f"⏳ Kutilmoqda: {db.count_words(lang, 'pending')}")


def preview(w):
    warn = "" if w["mnemonic"] else "\n\n⚠️ AI mnemonika yaratmadi. 🔄 tugmasini bosing."
    return (f"{FLAG[w['lang']]}\n\n<b>{w['word']}</b> [{w['ipa']}]\n= {w['translation']}\n\n"
            f"🧠 {w['mnemonic']}\n\n💬 {w['example']}{warn}")


def word_kb(w):
    return kb([("✅ Tasdiqlash", f"ok:{w['id']}"), ("🔄 Boshqa mnemonika", f"redo:{w['id']}")],
              [("🗑 O'chirish", f"del:{w['id']}")])


async def enrich_into(wid):
    w = db.get_word(wid)
    r = await ai.enrich_word(w["lang"], w["word"], w["translation"])
    db.update_word(wid, ipa=r["ipa"], mnemonic=r["mnemonic"], example=r["example"])


@router.message(CommandStart())
@router.message(Command("menu"))
async def start(m: Message, state: FSMContext):
    await state.clear()
    await m.answer("Yodla Admin 🔐\nBo'limni tanlang:", reply_markup=main_kb())


@router.message(Command("grant"))
async def grant(m: Message):
    """/grant email max 30  : to'lov qilgan foydalanuvchiga tarif berish"""
    parts = (m.text or "").split()
    if len(parts) != 4 or parts[2] not in ("max", "ultra") or not parts[3].isdigit():
        return await m.answer("Format: /grant email max|ultra kun\nMasalan: /grant ali@mail.com max 30")
    u = db.user_by_email(parts[1])
    if not u:
        return await m.answer("Bunday email topilmadi")
    until = db.grant_plan(u["id"], parts[2], min(int(parts[3]), 400))
    await m.answer(f"✅ {u['name']} {u['surname']}: {parts[2].upper()} {until} gacha")
    if u["tg_chat_id"]:
        await notify.send_user(u["tg_chat_id"], f"🎉 {u['name']}, {parts[2].upper()} tarifing {until} gacha faollashtirildi! Yodlashda omad 💪")


@router.callback_query(F.data == "home")
async def home(c: CallbackQuery, state: FSMContext):
    await state.clear()
    await c.message.edit_text("Yodla Admin 🔐\nBo'limni tanlang:", reply_markup=main_kb())
    await c.answer()


@router.callback_query(F.data.startswith("lang:"))
async def lang_menu(c: CallbackQuery, state: FSMContext):
    await state.clear()
    lang = c.data.split(":")[1]
    await c.message.edit_text(lang_text(lang), reply_markup=lang_kb(lang))
    await c.answer()


@router.callback_query(F.data == "stats")
async def stats(c: CallbackQuery):
    s = db.stats()
    text = (f"📊 Statistika\n\n👥 Foydalanuvchilar: {s['users']} (Telegram ulangan: {s['linked']})\n"
            f"📚 Bugun yodlangan so'zlar: {s['learned_today']}\n"
            f"💎 Pullik: {', '.join(f'{k} {v}' for k, v in s['plans'].items()) or 'yo`q'}\n\n"
            f"🇬🇧 {s['en_ok']} tasdiqlangan, {s['en_pending']} kutilmoqda\n"
            f"🇷🇺 {s['ru_ok']} tasdiqlangan, {s['ru_pending']} kutilmoqda")
    await c.message.edit_text(text, reply_markup=kb([("⬅️ Orqaga", "home")]))
    await c.answer()


# ---------- bitta so'z qo'shish ----------
@router.callback_query(F.data.startswith("add:"))
async def add_start(c: CallbackQuery, state: FSMContext):
    lang = c.data.split(":")[1]
    await state.set_state(Add.word)
    await state.update_data(lang=lang)
    await c.message.edit_text(f"{FLAG[lang]}\n\nSo'zni yozing:", reply_markup=kb([("❌ Bekor qilish", f"lang:{lang}")]))
    await c.answer()


@router.message(Add.word, F.text)
async def add_word(m: Message, state: FSMContext):
    word = m.text.strip()
    d = await state.get_data()
    if len(word) > 60:
        return await m.answer("Juda uzun. Bitta so'z yoki qisqa ibora yozing.")
    if db.word_exists(d["lang"], word):
        return await m.answer("Bu so'z bazada bor. Boshqasini yozing:")
    await state.update_data(word=word)
    await state.set_state(Add.translation)
    await m.answer(f"<b>{word}</b>\nO'zbekcha tarjimasi?", parse_mode="HTML")


@router.message(Add.translation, F.text)
async def add_translation(m: Message, state: FSMContext):
    d = await state.get_data()
    tr = m.text.strip()[:80]
    await state.clear()
    wid = db.add_word(d["lang"], d["word"], tr)
    wait = await m.answer("🧠 AI mnemonika yaratyapti…")
    try:
        await enrich_into(wid)
    except ai.AIError as e:
        logging.warning("AI xato: %s", e)
    await wait.edit_text(preview(db.get_word(wid)), parse_mode="HTML", reply_markup=word_kb(db.get_word(wid)))


@router.callback_query(F.data.startswith("ok:"))
async def approve(c: CallbackQuery):
    wid = int(c.data.split(":")[1])
    w = db.get_word(wid)
    if not w:
        return await c.answer("Topilmadi")
    if not w["mnemonic"]:
        return await c.answer("Avval mnemonika yarating (🔄)", show_alert=True)
    db.update_word(wid, status="approved")
    await c.message.edit_text(f"✅ Tasdiqlandi: <b>{w['word']}</b> = {w['translation']}", parse_mode="HTML",
                              reply_markup=kb([("➕ Yana qo'shish", f"add:{w['lang']}"),
                                               ("⏳ Keyingisi", f"pend:{w['lang']}")],
                                              [("⬅️ Orqaga", f"lang:{w['lang']}")]))
    await c.answer("Tasdiqlandi")


@router.callback_query(F.data.startswith("redo:"))
async def redo(c: CallbackQuery):
    wid = int(c.data.split(":")[1])
    if not db.get_word(wid):
        return await c.answer("Topilmadi")
    await c.answer("AI o'ylayapti…")
    try:
        await enrich_into(wid)
    except ai.AIError as e:
        return await c.message.answer(f"AI xatosi: {e}")
    w = db.get_word(wid)
    await c.message.edit_text(preview(w), parse_mode="HTML", reply_markup=word_kb(w))


@router.callback_query(F.data.startswith("del:"))
async def delete(c: CallbackQuery):
    wid = int(c.data.split(":")[1])
    w = db.get_word(wid)
    db.delete_word(wid)
    lang = w["lang"] if w else "en"
    await c.message.edit_text("🗑 O'chirildi", reply_markup=kb([("⏳ Keyingisi", f"pend:{lang}")],
                                                              [("⬅️ Orqaga", f"lang:{lang}")]))
    await c.answer()


# ---------- ko'plab qo'shish ----------
@router.callback_query(F.data.startswith("bulk:"))
async def bulk_start(c: CallbackQuery, state: FSMContext):
    lang = c.data.split(":")[1]
    await state.set_state(Bulk.text)
    await state.update_data(lang=lang)
    await c.message.edit_text(
        f"{FLAG[lang]}\n\nHar qatorga bittadan yozing (eng ko'pi 150 ta):\n\n"
        "<code>reluctant - istamaydigan\naberration - g'alati holat</code>",
        parse_mode="HTML", reply_markup=kb([("❌ Bekor qilish", f"lang:{lang}")]))
    await c.answer()


@router.message(Bulk.text, F.text)
async def bulk_run(m: Message, state: FSMContext):
    lang = (await state.get_data())["lang"]
    await state.clear()
    pairs, skipped = [], 0
    for line in m.text.splitlines()[:150]:
        pr = parse_line(line)
        if not pr or len(pr[0]) > 60:
            skipped += 1 if line.strip() else 0
            continue
        word, tr = pr[0], pr[1][:80]
        if db.word_exists(lang, word) or any(p[0].lower() == word.lower() for p in pairs):
            skipped += 1
            continue
        pairs.append((word, tr))
    if not pairs:
        return await m.answer("Hech narsa qo'shilmadi. Format: so'z - tarjima", reply_markup=lang_kb(lang))
    wait = await m.answer(f"⏳ {len(pairs)} ta so'z qo'shilmoqda, AI ishlayapti…")
    sem, failed = asyncio.Semaphore(4), 0

    async def one(word, tr):
        nonlocal failed
        wid = db.add_word(lang, word, tr)
        async with sem:
            try:
                await enrich_into(wid)
            except ai.AIError as e:
                failed += 1
                logging.warning("AI xato: %s", e)

    await asyncio.gather(*(one(w, t) for w, t in pairs))
    text = f"✅ {len(pairs)} ta so'z qo'shildi (tasdiq kutmoqda)."
    if failed:
        text += f"\n⚠️ {failed} tasida AI mnemonika yaratmadi, ularni ko'rib chiqishda 🔄 bosing."
    if skipped:
        text += f"\n↩️ {skipped} ta qator o'tkazib yuborildi (takror yoki noto'g'ri format)."
    await wait.edit_text(text, reply_markup=kb([("✅ Hammasini tasdiqlash", f"okall:{lang}")],
                                               [("⏳ Birma-bir ko'rish", f"pend:{lang}")],
                                               [("⬅️ Orqaga", f"lang:{lang}")]))


@router.callback_query(F.data.startswith("okall:"))
async def approve_all(c: CallbackQuery):
    lang = c.data.split(":")[1]
    n = db.approve_all_pending(lang)
    left = db.count_words(lang, "pending")
    await c.message.edit_text(f"✅ {n} ta so'z tasdiqlandi." + (f"\n⚠️ {left} tasi mnemonikasiz qoldi." if left else ""),
                              reply_markup=kb([("⏳ Qolganlarini ko'rish", f"pend:{lang}")] if left else [],
                                              [("⬅️ Orqaga", f"lang:{lang}")]))
    await c.answer()


# ---------- tasdiq kutayotganlar va ro'yxat ----------
@router.callback_query(F.data.startswith("pend:"))
async def pending(c: CallbackQuery):
    lang = c.data.split(":")[1]
    w = db.first_pending(lang)
    if not w:
        await c.message.edit_text("⏳ Tasdiq kutayotgan so'z yo'q 🎉", reply_markup=lang_kb(lang))
    else:
        left = db.count_words(lang, "pending")
        await c.message.edit_text(f"({left} ta qoldi)\n\n" + preview(w), parse_mode="HTML", reply_markup=word_kb(w))
    await c.answer()


@router.callback_query(F.data.startswith("list:"))
async def list_words(c: CallbackQuery):
    lang = c.data.split(":")[1]
    rows = db.list_words(lang, "approved", 40)
    body = "\n".join(f"• {r['word']} = {r['translation']}" for r in rows) or "Hali so'z yo'q"
    await c.message.edit_text(f"{FLAG[lang]}\nSo'nggi tasdiqlanganlar:\n\n{body}"[:4000], reply_markup=lang_kb(lang))
    await c.answer()


async def main():
    logging.basicConfig(level=logging.INFO)
    if not config.ADMIN_BOT_TOKEN:
        raise SystemExit("ADMIN_BOT_TOKEN .env faylida yo'q")
    if not config.ADMIN_IDS:
        raise SystemExit("ADMIN_IDS .env faylida yo'q (o'zingizning Telegram ID'ingizni yozing)")
    db.init()
    bot = Bot(config.ADMIN_BOT_TOKEN)
    dp = Dispatcher()
    dp.include_router(router)
    print("Admin bot ishga tushdi ✅")
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
