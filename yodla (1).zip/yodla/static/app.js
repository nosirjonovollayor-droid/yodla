(() => {
'use strict';
const DEMO = !!window.YODLA_DEMO;
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt = n => String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
const rnd = a => a[Math.floor(Math.random() * a.length)];
const S = {me: null, plans: null, cycle: 'month', view: 'home', cur: null, rev: null, Q: null,
           reg: {name: '', sur: '', mail: '', pass: '', lang: 'en', daily: 10, domla: 'h', plan: 'free'}};
const root = () => $('#root');

/* ---------- yordamchilar ---------- */
async function api(path, method = 'GET', body) {
  if (DEMO) return window.mockApi(path, method, body);
  let r;
  try { r = await fetch('/api' + path, {method, headers: {'Content-Type': 'application/json'}, credentials: 'same-origin', body: body ? JSON.stringify(body) : undefined}); }
  catch (e) { throw {status: 0, msg: 'Internet bilan muammo 😅 Qayta urin'}; }
  let j = {}; try { j = await r.json(); } catch (e) {}
  if (!r.ok) throw {status: r.status, msg: typeof j.detail === 'string' ? j.detail : 'Maʼlumot notoʻgʻri, tekshirib qayta urin'};
  return j;
}
function toast(m) { const t = $('#toast'); t.textContent = m; t.classList.add('on'); clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('on'), 3400); }
function fail(e) { if (e.status === 401 && S.me) { location.reload(); return; } toast(e.msg || 'Xatolik'); }
function burst() {
  ['🎉','✨','🧠','😂','⭐','💥','🔥','😎'].forEach((c, i) => { const s = document.createElement('span'); s.className = 'cf'; s.textContent = c;
    const a = i / 8 * 6.28; s.style.setProperty('--x', Math.cos(a) * 160 + 'px'); s.style.setProperty('--y', Math.sin(a) * 160 + 'px'); s.style.setProperty('--r', i * 50 + 'deg');
    document.body.appendChild(s); setTimeout(() => s.remove(), 1400); });
}
function speak(text, lang) { if (!window.speechSynthesis) { toast('Brauzering ovoz chiqarishni qoʻllamaydi'); return; }
  const u = new SpeechSynthesisUtterance(text); u.lang = lang === 'ru' ? 'ru-RU' : 'en-US'; u.rate = .9; speechSynthesis.cancel(); speechSynthesis.speak(u); }
function busy(b, on, txt) { if (!b) return; if (on) { b.dataset.t = b.innerHTML; b.innerHTML = txt; b.disabled = true; } else { b.innerHTML = b.dataset.t || b.innerHTML; b.disabled = false; } }
function bad(el) { if (!el) return; el.classList.remove('shake'); void el.offsetWidth; el.classList.add('shake'); }
const ICON = {free: '🌱', max: '⚡', ultra: '👑'};
const HELLO = {h: ['Bugun ham kulib yodlaymizmi? 😄', 'Miyang tayyormi? 🧠', 'Bugungi soʻzlar seni kutyapti 😏'],
               q: ['Bahona yoʻq. Bugungi maqsadni bajar! 😤', 'Vaqt ketyapti, boshla! 💪', 'Seriyani uzma! 🔥']};

/* ---------- tariflar ---------- */
function planCard(p, mode, sel) {
  const y = S.cycle === 'year', price = y ? p.year : p.month;
  const cls = ['plan', p.id === 'max' ? 'pop2' : '', p.id === 'ultra' ? 'ult' : '', sel === p.id ? 'on' : ''].join(' ');
  const save = y && p.month ? `🎁 ${fmt(p.month * 12 - p.year)} soʻm tejaysan` : '';
  const feats = p.features.map(f => `<li class="${f.endsWith('yoʻq') || f.endsWith('yo‘q') ? 'no' : ''}">${esc(f)}</li>`).join('');
  let btn = '';
  if (mode === 'app') {
    const cur = S.me.plan === p.id, paid = S.me.trial_used || S.me.plan !== 'free';
    btn = cur ? '<button class="btn g blk" disabled>Hozirgi tarif ✓</button>' : p.id === 'free' ? '' :
      `<button class="btn blk" data-act="trial" data-v="${p.id}">${paid ? 'Toʻlov: ' + esc(S.plans.pay) : S.plans.trial_days + ' kun bepul sinash'}</button>`;
  }
  return `<div class="${cls}" ${mode === 'reg' ? `data-act="pickplan" data-v="${p.id}"` : ''}>
    ${p.popular ? '<span class="tag">⭐ Mashhur</span>' : ''}
    <div><h3>${ICON[p.id]} ${esc(p.name)}</h3></div>
    <div class="pr"><b data-to="${price}">${fmt(price)}</b> <small>soʻm / ${y ? 'yil' : 'oy'}</small></div>
    <div class="save">${save}</div><ul>${feats}</ul>${btn}</div>`;
}
const plansHTML = (mode, sel) => `<div class="plans">${S.plans.plans.map(p => planCard(p, mode, sel)).join('')}</div>`;
const cycleHTML = () => `<div class="seg"><button data-act="cycle" data-v="month" class="${S.cycle === 'month' ? 'on' : ''}">Oylik</button><button data-act="cycle" data-v="year" class="${S.cycle === 'year' ? 'on' : ''}">Yillik · 2 oy sovgʻa</button></div>`;
function countUps() { $$('.pr b[data-to]').forEach(el => { const to = +el.dataset.to; if (!to) return; const t0 = performance.now();
  const step = t => { const k = Math.min(1, (t - t0) / 700), e = 1 - Math.pow(1 - k, 3); el.textContent = fmt(Math.round(to * e)); if (k < 1) requestAnimationFrame(step); }; requestAnimationFrame(step); }); }
function repaintPlans(mode) { const box = $('#plansbox'); if (!box) return; box.innerHTML = plansHTML(mode, mode === 'reg' ? S.reg.plan : S.me && S.me.plan); $$('.seg button').forEach(b => b.classList.toggle('on', b.dataset.v === S.cycle)); countUps(); }

/* ---------- kirish va ro'yxatdan o'tish ---------- */
const ART = `<div class="logo" style="--s:64px"></div><h1>Soʻzni <span class="gt">kulib</span> yodla</h1>
<p>Har bir soʻzga kulgili oʻzbekcha mnemonika. AI domla gapingni tekshiradi, unutishdan oldin takrorlatadi.</p>
<div class="fl" style="top:10%;right:9%">reluctant<small>istamaydigan</small></div>
<div class="fl s2" style="top:36%;right:3%;animation-delay:-2s">упрямый<small>oʻjar</small></div>
<div class="fl" style="bottom:24%;right:15%;animation-delay:-4s">aberration<small>gʻalati holat</small></div>
<div class="fl s2" style="bottom:9%;right:3%;animation-delay:-1s">🔥 12 kunlik seriya</div>`;
function shell(inner, wide) { root().innerHTML = `<div class="auth ${wide ? 'w' : ''}"><div class="art">${ART}</div><div class="panel"><div class="pin ${wide ? 'wide' : ''}">${inner}</div></div></div>`; }
const stepper = n => `<div class="stepper">${[1, 2, 3, 4].map(i => `<i class="${i <= n ? 'on' : ''}"></i>`).join('')}</div>`;

function splash() {
  root().innerHTML = '<div class="splash"><div class="logo"></div><div class="wm">Yodla</div><div class="sub">Soʻzni kulib yodla</div></div>';
  setTimeout(welcome, 2900);
}
function welcome() {
  shell(`<div class="col"><div class="logo" style="--s:60px"></div><h2 style="font-size:34px">Xush kelibsan! 👋</h2>
  <p class="mut">Hisob och va bugunoq birinchi soʻzingni yodla.</p>
  <button class="btn blk" data-act="reg" data-primary>Boshlash 🚀</button><button class="btn g blk" data-act="login">Akkauntim bor, kirish</button>
  <div class="row wrap" style="gap:8px"><span class="pill">🇬🇧 Ingliz</span><span class="pill">🇷🇺 Rus</span><span class="pill">🤖 AI domla</span><span class="pill">📲 Telegram</span></div></div>`);
}
function loginScr() {
  shell(`<div class="col"><h2 style="font-size:30px">Qaytganingga xursandmiz 😄</h2>
  <label class="f">Email<input class="inp" id="l-mail" type="email" autocomplete="email" placeholder="ali@gmail.com"></label>
  <label class="f">Parol<input class="inp" id="l-pass" type="password" autocomplete="current-password" placeholder="••••••"></label>
  <div class="err" id="err"></div>
  <button class="btn blk" data-act="dologin" data-primary>Kirish</button><button class="btn g blk" data-act="welcome">⬅️ Orqaga</button></div>`);
}
function R1() {
  const r = S.reg;
  shell(`${stepper(1)}<div class="col"><h2 style="font-size:30px">Tanishamiz 😄</h2>
  <div class="grid g2" style="gap:12px"><label class="f">Ism<input class="inp" id="r-name" autocomplete="given-name" value="${esc(r.name)}" placeholder="Ali"></label>
  <label class="f">Familiya<input class="inp" id="r-sur" autocomplete="family-name" value="${esc(r.sur)}" placeholder="Valiyev"></label></div>
  <label class="f">Email<input class="inp" id="r-mail" type="email" autocomplete="email" value="${esc(r.mail)}" placeholder="ali@gmail.com"></label>
  <label class="f">Parol (kamida 6 belgi)<span style="position:relative;display:block"><input class="inp" id="r-pass" type="password" autocomplete="new-password" value="${esc(r.pass)}" placeholder="••••••"><button type="button" data-act="eye" style="position:absolute;right:12px;top:12px;font-size:20px" aria-label="Parolni koʻrsatish">👁</button></span></label>
  <div class="err" id="err"></div>
  <button class="btn blk" data-act="r1" data-primary>Davom etish →</button><button class="btn g blk" data-act="welcome">⬅️ Orqaga</button></div>`);
}
function R2() {
  const r = S.reg;
  shell(`${stepper(2)}<div class="col"><h2 style="font-size:30px">Qaysi tilni oʻrganasan? 🌍</h2>
  <div class="grid g2" style="gap:12px"><button class="lang ${r.lang === 'en' ? 'on' : ''}" data-act="lang" data-v="en"><span>🇬🇧</span>Ingliz tili</button><button class="lang ${r.lang === 'ru' ? 'on' : ''}" data-act="lang" data-v="ru"><span>🇷🇺</span>Rus tili</button></div>
  <h3 style="margin-top:6px">Kuniga nechta yangi soʻz? 🎯</h3>
  <div class="row wrap">${[5, 10, 15, 20, 30].map(n => `<button class="chip ${r.daily === n ? 'on' : ''}" data-act="goal" data-v="${n}">${n}</button>`).join('')}</div>
  <div class="card" style="padding:14px 16px">1 oylik maqsad: <b class="gt" id="mon">${r.daily * 30}</b> ta soʻz</div>
  <button class="btn blk" data-act="r2" data-primary>Davom etish →</button><button class="btn g blk" data-act="reg">⬅️ Orqaga</button></div>`);
}
function R3() {
  shell(`${stepper(3)}<div class="col"><div class="c"><h2 style="font-size:32px">Tarifingni tanla 💎</h2><p class="mut">Max va Ultra uchun ${S.plans.trial_days} kun bepul sinov. Istalgan payt Free'ga qaytasan.</p></div>
  <div class="c">${cycleHTML()}</div><div id="plansbox">${plansHTML('reg', S.reg.plan)}</div>
  <div class="row" style="justify-content:center;flex-wrap:wrap"><button class="btn g" data-act="r2b">⬅️ Orqaga</button><button class="btn" data-act="r3" data-primary>Davom etish →</button></div></div>`, true);
  countUps();
}
function R4() {
  const r = S.reg;
  shell(`${stepper(4)}<div class="col"><h2 style="font-size:30px">Domlani tanla 🎓</h2><p class="mut">Keyin sozlamalardan oʻzgartirsang boʻladi.</p>
  <button class="dom ${r.domla === 'h' ? 'on' : ''}" data-act="dom" data-v="h"><span>😄</span><div><b>Hazilkash</b><small>Kulib yodlaymiz, xatoingga hazil qilaman</small></div></button>
  <button class="dom ${r.domla === 'q' ? 'on' : ''}" data-act="dom" data-v="q"><span>😤</span><div><b>Qattiq ustoz</b><small>Bahona yoʻq, xato qilsang tergayman</small></div></button>
  <div class="err" id="err"></div>
  <button class="btn blk" data-act="r4" data-primary>Hisob yaratish 🚀</button><button class="btn g blk" data-act="r3b">⬅️ Orqaga</button></div>`);
}
function boom() {
  const d = document.createElement('div'); d.className = 'boom';
  d.innerHTML = `<div class="rock">🚀</div><h1>Xoʻsh, <span class="gt">${esc(S.me.name)}</span>,<br>qani ketdik unda!</h1><p class="mut">Domlang seni kutyapti…</p>`;
  document.body.appendChild(d); burst(); setTimeout(() => { d.remove(); enterApp(); }, 2700);
}

/* ---------- ilova qobig'i ---------- */
const NAV = [['home','🏠','Bosh sahifa'],['learn','📚','Yodlash'],['review','🔁','Takrorlash'],['quiz','🎯','Test'],['essay','✍️','Essay'],
             ['speak','🎤','Gapir'],['book','🗂','Daftar'],['board','🏆','Reyting'],['plans','💎','Tariflar'],['settings','⚙️','Sozlamalar']];
const TAB = [['home','🏠','Bosh'],['learn','📚','Yodlash'],['review','🔁','Takror'],['quiz','🎯','Test'],['more','☰','Yana']];
async function enterApp() {
  if (!S.plans) S.plans = await api('/plans');
  root().innerHTML = `<div class="shell"><aside class="side"><div class="brand"><div class="logo"></div>Yodla</div>
    ${NAV.map(n => `<button class="nv" data-act="nav" data-v="${n[0]}"><span>${n[1]}</span>${n[2]}</button>`).join('')}<div class="sp1"></div><div class="card" id="sideplan" style="padding:14px"></div></aside>
    <main class="main"><header class="top"><h2 id="ttl"></h2><div class="row"><span class="pill" id="sk"></span><button class="pill" data-act="theme" aria-label="Mavzu">🌓</button></div></header><div id="view"></div></main></div>
    <nav class="tabbar">${TAB.map(n => `<button data-act="nav" data-v="${n[0]}"><span>${n[1]}</span>${n[2]}</button>`).join('')}</nav>`;
  paintTop(); setView(S.view || 'home');
}
function paintTop() {
  const m = S.me; if (!m || !$('#sk')) return;
  $('#sk').textContent = '🔥 ' + m.streak;
  const until = m.plan !== 'free' && m.plan_until ? `<div class="mut" style="font-size:12px">${esc(m.plan_until)} gacha</div>` : '';
  $('#sideplan').innerHTML = `<div class="b">${ICON[m.plan]} ${m.plan.toUpperCase()}</div>${until}${m.plan !== 'ultra' ? '<button class="btn sm blk" style="margin-top:10px" data-act="nav" data-v="plans">Oshirish 💎</button>' : ''}`;
}
async function refreshMe() { try { S.me = await api('/me'); paintTop(); } catch (e) {} }
function setView(v) {
  S.view = v; const title = (NAV.find(n => n[0] === v) || ['', '', v === 'more' ? 'Yana' : ''])[2];
  $('#ttl').textContent = title;
  $$('.nv').forEach(b => b.classList.toggle('on', b.dataset.v === v));
  $$('.tabbar button').forEach(b => b.classList.toggle('on', b.dataset.v === v || (b.dataset.v === 'more' && !TAB.some(t => t[0] === v))));
  const view = $('#view'); view.innerHTML = '<div class="card c mut fade">Yuklanmoqda…</div>'; window.scrollTo(0, 0);
  (V[v] || V.home)().catch(fail);
}
const put = html => { const v = $('#view'); if (v) { v.innerHTML = `<div class="fade">${html}</div>`; } };

/* ---------- bo'limlar ---------- */
const ring = (done, goal) => { const p = Math.min(1, done / Math.max(1, goal)), C = 2 * Math.PI * 58;
  return `<div class="ringw"><svg viewBox="0 0 140 140" width="100%" height="100%"><defs><linearGradient id="gr" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#19C3AB"/><stop offset="1" stop-color="#7C5CFF"/></linearGradient></defs>
  <circle cx="70" cy="70" r="58" fill="none" stroke="var(--card2)" stroke-width="14"/><circle cx="70" cy="70" r="58" fill="none" stroke="url(#gr)" stroke-width="14" stroke-linecap="round" stroke-dasharray="${C}" stroke-dashoffset="${C * (1 - p)}" style="--C:${C};animation:ringin 1.2s ease both"/></svg>
  <div class="t"><b>${done}/${goal}</b><span>bugun</span></div></div>`; };
const lockCard = (icon, title, text, btn) => `<div class="card lockc"><span>${icon}</span><h3>${title}</h3><p class="mut">${text}</p>${btn || '<button class="btn" data-act="nav" data-v="plans">Tariflarni koʻrish 💎</button>'}</div>`;

const V = {
  async home() {
    const [act, me] = await Promise.all([api('/activity'), api('/me')]); S.me = me; paintTop();
    const days = act.days, last7 = days.slice(-7), mx = Math.max(1, ...last7.map(d => d.count));
    const wd = ['Ya', 'Du', 'Se', 'Ch', 'Pa', 'Ju', 'Sh'];
    const bars = last7.map(d => `<div><i style="height:${Math.max(4, d.count / mx * 100)}%" title="${d.count}"></i>${wd[new Date(d.day + 'T12:00:00').getDay()]}</div>`).join('');
    const heat = days.map(d => `<i class="${d.count >= 8 ? 'l3' : d.count >= 4 ? 'l2' : d.count > 0 ? 'l1' : ''}" title="${esc(d.day)}: ${d.count}"></i>`).join('');
    put(`<p class="mut" style="margin:-10px 0 18px;font-weight:700">Salom, ${esc(me.name)}! ${rnd(HELLO[me.domla])}</p>
    <div class="grid" style="grid-template-columns:1.3fr 1fr;gap:16px">
      <div class="card row" style="gap:24px">${ring(me.done, me.daily)}<div class="col" style="gap:10px"><h3>Bugungi maqsad</h3><p class="mut">${me.done >= me.daily ? 'Barakalla! Maqsad bajarildi 🎉' : (me.daily - me.done) + ' ta soʻz qoldi'}</p><button class="btn" data-act="nav" data-v="learn">${me.done ? 'Davom etish' : 'Boshlash'} →</button></div></div>
      <div class="grid g2" style="gap:12px"><div class="card stat"><b>🔥 ${me.streak}</b><span>kunlik seriya</span></div><div class="card stat"><b>📚 ${me.total}</b><span>yodlangan soʻz</span></div>
      <div class="card stat" style="grid-column:span 2"><b>${ICON[me.plan]} ${me.plan.toUpperCase()}</b><span>${me.plan === 'free' ? 'Max bilan 4 barobar koʻp soʻz' : (me.plan_until || '') + ' gacha'}</span></div></div></div>
    <div class="grid g2" style="margin-top:16px"><div class="card col"><h3>Haftalik faollik</h3><div class="bars">${bars}</div></div><div class="card col"><h3>Oxirgi 28 kun</h3><div class="heat">${heat}</div><p class="mut" style="font-size:13px">Qanchalik toʻq, shuncha koʻp soʻz yodlagansan</p></div></div>
    <h3 style="margin:22px 0 12px">Tezkor amallar</h3>
    <div class="grid g4"><button class="card qa" data-act="nav" data-v="review"><span>🔁</span>Takrorlash</button><button class="card qa" data-act="nav" data-v="quiz"><span>🎯</span>Test</button><button class="card qa" data-act="nav" data-v="essay"><span>✍️</span>Essay</button><button class="card qa" data-act="nav" data-v="speak"><span>🎤</span>Gapir</button></div>`);
  },
  async learn() {
    const r = await api('/today'); S.cur = r.word; S.me.done = r.done;
    if (!r.word) return put(lockCard(r.limit ? '⏳' : '🎉', r.limit ? 'Bugungi limit tugadi' : 'Hozircha yangi soʻz yoʻq',
      r.limit ? 'Ertaga yangi soʻzlar ochiladi. Koʻproq yodlash uchun tarifni oshir.' : 'Yangi soʻzlar qoʻshilgach shu yerda chiqadi. Hozircha takrorlash bilan shugʻullan.',
      r.limit ? '' : '<button class="btn" data-act="nav" data-v="review">Takrorlashga oʻtish 🔁</button>'));
    const w = r.word;
    put(`<div class="grid" style="grid-template-columns:1.2fr 1fr;gap:16px;align-items:start"><div class="wcard"><div class="row sp"><span class="pill">📚 Bugungi soʻz</span><span class="pill">${r.done}/${r.goal}</span></div>
      <div class="row" style="gap:14px"><div class="w">${esc(w.word)}</div><button class="spk" data-act="say" data-t="${esc(w.word)}" aria-label="Tinglash">🔊</button></div>
      ${w.ipa ? `<div class="mut b">[${esc(w.ipa)}]</div>` : ''}<h2 class="gt" style="font-size:30px">${esc(w.translation)}</h2>
      ${w.mnemonic ? `<div class="mn">🧠 ${esc(w.mnemonic)}</div>` : ''}${w.example ? `<div class="row"><div class="mut" style="flex:1;font-weight:600">💬 ${esc(w.example)}</div><button class="spk" data-act="say" data-t="${esc(w.example.split('(')[0])}">🔊</button></div>` : ''}</div>
      <div class="card col"><h3>Shu soʻz bilan gap tuz ✍️</h3><textarea class="inp" id="gap" style="min-height:96px" placeholder="Oʻz gapingni yoz…"></textarea>
      <button class="btn blk" data-act="check" data-primary>Tekshir 😏</button><div class="bub" id="res" style="display:none"></div><p class="mut" style="font-size:12px">AI limiti: ${S.me.limits.ai_left}/${S.me.limits.ai} qoldi</p></div></div>`);
  },
  async review() {
    const r = await api('/review'); S.rev = r.word;
    if (!r.word) return put(lockCard('🎉', 'Takrorlash yoʻq', 'Hozir takrorlaydigan soʻz yoʻq. Yangi soʻz yodla, u kerakli vaqtda shu yerga qaytadi.', '<button class="btn" data-act="nav" data-v="learn">Yodlashga oʻtish 📚</button>'));
    const w = r.word;
    put(`<div class="col" style="max-width:640px;margin:0 auto"><div class="row sp"><span class="pill">🔁 Takrorlash kerak: ${r.due}</span><button class="spk" data-act="say" data-t="${esc(w.word)}">🔊</button></div>
      <div class="flip" data-act="flip"><div class="fi"><div class="fa"><div style="font-size:clamp(34px,7vw,56px);font-weight:800">${esc(w.word)}</div><p class="mut">bosib javobni koʻr 👆</p></div>
      <div class="fb"><div style="font-size:30px;font-weight:800">${esc(w.translation)}</div><p style="font-weight:600">${esc(w.mnemonic)}</p></div></div></div>
      <div class="grid g2" style="gap:12px"><button class="btn g" data-act="rev" data-v="0">😅 Unutdim</button><button class="btn" data-act="rev" data-v="1">✅ Esladim</button></div></div>`);
  },
  async quiz() {
    const l = S.me.limits; S.Q = null;
    put(`<div class="card col c" style="max-width:560px;margin:0 auto;align-items:center"><span style="font-size:64px">🎯</span><h2>Bilimingni sinab koʻr</h2>
      <p class="mut">Yodlagan soʻzlaringdan test tuziladi. Xato qilganing takrorlashga qaytadi.</p>
      <span class="pill">Bugun qoldi: ${l.quiz_left}/${l.quiz} marta</span><button class="btn" data-act="qstart">Testni boshlash →</button></div>`);
  },
  async essay() {
    const l = S.me.limits;
    put(`<div class="grid" style="grid-template-columns:1.2fr 1fr;gap:16px;align-items:start"><div class="card col"><h3>Essay yoz ✍️ <span class="mut" style="font-size:14px">(${S.me.lang === 'en' ? 'ingliz' : 'rus'} tilida)</span></h3>
      <textarea class="inp" id="es" style="min-height:240px" placeholder="${S.me.lang === 'en' ? 'My favorite place is…' : 'Моё любимое место…'}"></textarea>
      <div class="row sp"><span class="mut" id="cnt">0 / 2000</span><button class="btn" data-act="essay" data-primary>Tekshir</button></div>
      <p class="mut" style="font-size:13px">Bugun qoldi: ${l.essay_left}/${l.essay}</p></div><div id="eres"><div class="card c mut">Domla fikri shu yerda chiqadi 👈</div></div></div>`);
  },
  async speak() {
    const l = S.me.limits;
    if (!l.speak) return put(lockCard('🎤', 'Gapirish mashqi', 'Mikrofonga gapir, domla matnni tekshirib, qanday yaxshilashni aytadi. Max va Ultra tariflarda.'));
    const T = {en: ['Describe your daily routine', 'Talk about your favorite place', 'What are your goals for next year?', 'Describe your best friend', 'Why is learning English important?'],
               ru: ['Расскажи о своём дне', 'Опиши любимое место', 'Какие у тебя цели на год?', 'Расскажи о лучшем друге', 'Почему важно учить русский?']}[S.me.lang];
    S.topic = T[0];
    put(`<div class="grid" style="grid-template-columns:1fr 1fr;gap:16px;align-items:start"><div class="card col"><h3>Mavzuni tanla</h3><div class="row wrap">${T.map((t, i) => `<button class="chip ${i ? '' : 'on'}" data-act="topic" data-t="${esc(t)}" style="text-align:left">${esc(t)}</button>`).join('')}</div>
      <div class="c"><button class="mic" id="mic" data-act="mic" aria-label="Mikrofon">🎤</button><p class="mut" style="margin-top:10px">Bosib gapir, qayta bosib toʻxtat</p></div>
      <textarea class="inp" id="sp-txt" placeholder="Gaping shu yerda matn boʻlib chiqadi (tahrirlash mumkin)…"></textarea>
      <button class="btn blk" data-act="speaksend">Domlaga yubor</button><p class="mut" style="font-size:12px">Domla nutqni matn sifatida tekshiradi (grammatika, soʻzlar). Talaffuzni baholamaydi. Bugun qoldi: ${l.speak_left}/${l.speak}</p></div>
      <div id="sres"><div class="card c mut">Natija shu yerda chiqadi 👈</div></div></div>`);
  },
  async book() {
    S.bf = 'all';
    put(`<div class="col"><input class="inp" id="q" placeholder="🔍 Soʻz yoki tarjima qidir…"><div class="row wrap"><button class="chip on" data-act="bf" data-v="all">Hammasi</button><button class="chip" data-act="bf" data-v="yodlangan">Yodlangan</button><button class="chip" data-act="bf" data-v="takrorlash">Takrorlash</button></div><div class="col" id="bl" style="gap:10px"></div></div>`);
    loadBook();
  },
  async board() {
    const r = await api('/leaderboard'), m = S.me;
    const A = [['🌱', 'Birinchi soʻz', m.total >= 1], ['🌿', '10 ta soʻz', m.total >= 10], ['🌳', '50 ta soʻz', m.total >= 50], ['🏔️', '100 ta soʻz', m.total >= 100], ['👑', '300 ta soʻz', m.total >= 300],
               ['🔥', '3 kunlik seriya', m.streak >= 3], ['⚡', '7 kunlik seriya', m.streak >= 7], ['💎', '30 kunlik seriya', m.streak >= 30]];
    put(`<div class="grid g2" style="align-items:start"><div class="col"><div class="row sp"><h3>Haftalik reyting 🏆</h3>${r.rank ? `<span class="pill">Sen: #${r.rank}</span>` : ''}</div>
      ${r.top.length ? r.top.map(t => `<div class="lb ${t.me ? 'me' : ''}"><div class="rk">${t.rank <= 3 ? ['🥇', '🥈', '🥉'][t.rank - 1] : t.rank}</div><div style="flex:1;font-weight:800">${esc(t.name)}</div><b>${t.pts} ta</b></div>`).join('') : '<div class="card c mut">Bu hafta hali hech kim soʻz yodlamagan. Birinchi boʻl! 🚀</div>'}</div>
      <div class="col"><h3>Yutuqlar 🎖</h3><div class="grid g3" style="gap:10px">${A.map(a => `<div class="bd ${a[2] ? '' : 'lock'}"><span>${a[0]}</span><small>${a[1]}</small></div>`).join('')}</div></div></div>`);
  },
  async plans() {
    const m = S.me, until = m.plan !== 'free' ? ` · ${esc(m.plan_until)} gacha` : '';
    put(`<div class="col"><div class="card row sp wrap"><div><div class="mut b" style="font-size:13px">HOZIRGI TARIFING</div><h2>${ICON[m.plan]} ${m.plan.toUpperCase()}<span class="mut" style="font-size:15px">${until}</span></h2></div>${cycleHTML()}</div>
      <div id="plansbox">${plansHTML('app', m.plan)}</div>
      <div class="card"><b>💳 Toʻlov qanday?</b><p class="mut" style="margin-top:6px">Sinov muddati tugagach, ${esc(S.plans.pay)} ga yozing: karta orqali toʻlov qilasiz va tarif shu zahoti faollashtiriladi. Click/Payme orqali avtomatik toʻlov tez kunda.</p></div></div>`);
    countUps();
  },
  async settings() {
    const m = S.me, hrs = [7, 8, 9, 10, 12, 15, 18, 20, 21, 22], goals = [3, 5, 10, 15, 20, 30, 50].filter(g => g <= m.limits.words);
    put(`<div class="grid g2" style="align-items:start"><div class="col">
      <div class="card col"><h3>👤 Profil</h3><div class="row sp"><span class="mut">Ism</span><b>${esc(m.name)} ${esc(m.surname)}</b></div><div class="row sp"><span class="mut">Email</span><b>${esc(m.email)}</b></div></div>
      <div class="card col"><h3>🎯 Oʻrganish</h3><label class="f">Til<select class="inp" data-set="lang"><option value="en" ${m.lang === 'en' ? 'selected' : ''}>🇬🇧 Ingliz tili</option><option value="ru" ${m.lang === 'ru' ? 'selected' : ''}>🇷🇺 Rus tili</option></select></label>
        <label class="f">Kunlik maqsad<select class="inp" data-set="daily">${goals.map(g => `<option value="${g}" ${g === m.daily ? 'selected' : ''}>Kuniga ${g} ta soʻz</option>`).join('')}</select></label>
        <label class="f">Domla<select class="inp" data-set="domla"><option value="h" ${m.domla === 'h' ? 'selected' : ''}>😄 Hazilkash</option><option value="q" ${m.domla === 'q' ? 'selected' : ''}>😤 Qattiq ustoz</option></select></label></div></div>
      <div class="col"><div class="card col"><h3>📲 Telegram</h3><p class="mut">${m.tg ? 'Ulangan ✅ Eslatmalar botga keladi.' : 'Ulab qoʻysang, domla botda eslatma yuboradi.'}</p><button class="btn ${m.tg ? 'g' : ''}" data-act="tglink">${m.tg ? 'Qayta ulash' : 'Telegramni ulash'}</button>
        <label class="f">Eslatma vaqti<select class="inp" data-set="notify_hour">${hrs.map(h => `<option value="${h}" ${h === m.notify_hour ? 'selected' : ''}>${String(h).padStart(2, '0')}:00</option>`).join('')}</select></label>
        <button class="btn g" data-act="notif">${m.notify_on ? '🔔 Eslatmalar yoqilgan' : '🔕 Eslatmalar oʻchirilgan'}</button></div>
      <div class="card col"><h3>🎨 Koʻrinish</h3><button class="btn g" data-act="theme">🌓 Mavzuni almashtirish</button></div>
      <button class="btn g" style="color:var(--bad)" data-act="logout">Chiqish</button></div></div>`);
  },
  async more() {
    put(`<div class="grid g2">${NAV.filter(n => !TAB.some(t => t[0] === n[0])).map(n => `<button class="card qa" data-act="nav" data-v="${n[0]}"><span>${n[1]}</span>${n[2]}</button>`).join('')}</div>`);
  },
};
async function loadBook() {
  const q = ($('#q') || {}).value || '', box = $('#bl'); if (!box) return;
  const r = await api('/notebook?q=' + encodeURIComponent(q)); S.items = r.items; paintBook();
}
function paintBook() {
  const box = $('#bl'); if (!box) return; const L = (S.items || []).filter(x => S.bf === 'all' || x.status === S.bf);
  box.innerHTML = L.length ? L.map(x => `<div class="li fade"><div><b style="font-size:18px">${esc(x.word)}</b><div class="mut">${esc(x.translation)}</div></div><div class="row"><span class="tg" style="background:${x.status === 'yodlangan' ? 'var(--teal)' : 'var(--sun)'}">${x.status}</span><button class="spk" data-act="say" data-t="${esc(x.word)}">🔊</button></div></div>`).join('')
    : `<div class="card c mut">${(S.items || []).length ? 'Bu boʻlimda soʻz yoʻq' : 'Hali soʻz yodlamading. Bugungi soʻzdan boshla! 📚'}</div>`;
}
function renderQ() {
  const Q = S.Q, q = Q.qs[Q.i];
  if (!q) { const pct = Math.round(Q.score / Q.qs.length * 100);
    api('/quiz/result', 'POST', {wrong: Q.wrong, correct: Q.score}).then(refreshMe).catch(() => {}); if (pct >= 70) burst();
    return put(`<div class="card col c" style="max-width:560px;margin:0 auto;align-items:center"><span style="font-size:64px">${pct >= 70 ? '🏆' : '💪'}</span><h2>${Q.score} / ${Q.qs.length}</h2>
      <p class="mut">${pct >= 70 ? 'Zoʻr natija!' : 'Yomon emas, takrorlash bilan yaxshilanadi.'}${Q.wrong.length ? ' Xato qilganlaring takrorlashga qaytdi.' : ''}</p><div class="row wrap" style="justify-content:center"><button class="btn g" data-act="nav" data-v="review">🔁 Takrorlash</button><button class="btn" data-act="nav" data-v="quiz">Yana test</button></div></div>`); }
  put(`<div class="col" style="max-width:600px;margin:0 auto"><div class="row sp"><span class="pill">${Q.i + 1} / ${Q.qs.length}</span><span class="pill">✅ ${Q.score}</span></div><div class="prog"><i style="width:${Q.i / Q.qs.length * 100}%"></i></div>
    <div class="card c"><div class="mut b">Ma'nosi nima?</div><div style="font-size:clamp(34px,7vw,52px);font-weight:800;margin:6px 0">${esc(q.q)}</div>${q.ipa ? `<div class="mut">[${esc(q.ipa)}]</div>` : ''}</div>
    <div class="col" style="gap:10px">${q.options.map((o, i) => `<button class="opt" data-act="qans" data-i="${i}">${esc(o)}</button>`).join('')}</div></div>`);
}

/* ---------- amallar ---------- */
const A = {
  nav: el => setView(el.dataset.v),
  theme() { const t = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'; document.documentElement.dataset.theme = t; try { localStorage.setItem('yt_theme', t); } catch (e) {} },
  welcome: welcome, login: loginScr, reg: R1, r2b: R2, r3b: R3,
  eye() { const i = $('#r-pass'); i.type = i.type === 'password' ? 'text' : 'password'; },
  r1() {
    const n = $('#r-name'), s = $('#r-sur'), e = $('#r-mail'), p = $('#r-pass'), err = $('#err');
    const bad1 = (el, m) => { bad(el); err.textContent = m; };
    if (!n.value.trim()) return bad1(n, 'Ismingni yoz 😅');
    if (!s.value.trim()) return bad1(s, 'Familiyang ham kerak');
    if (!/^\S+@\S+\.\S+$/.test(e.value.trim())) return bad1(e, 'Email notoʻgʻri koʻrinyapti 🤨');
    if (p.value.length < 6) return bad1(p, 'Parol kamida 6 belgi boʻlsin 🔐');
    const nm = n.value.trim(); Object.assign(S.reg, {name: nm[0].toUpperCase() + nm.slice(1), sur: s.value.trim(), mail: e.value.trim(), pass: p.value}); R2();
  },
  lang(el) { S.reg.lang = el.dataset.v; $$('.lang').forEach(b => b.classList.toggle('on', b.dataset.v === S.reg.lang)); },
  goal(el) { S.reg.daily = +el.dataset.v; $$('[data-act=goal]').forEach(b => b.classList.toggle('on', +b.dataset.v === S.reg.daily)); $('#mon').textContent = S.reg.daily * 30; },
  r2: () => R3(),
  async pickplan(el) { S.reg.plan = el.dataset.v; $$('.plan').forEach(p => p.classList.toggle('on', p.dataset.v === S.reg.plan)); },
  cycle(el) { S.cycle = el.dataset.v; repaintPlans(S.me ? 'app' : 'reg'); },
  r3: () => R4(),
  dom(el) { S.reg.domla = el.dataset.v; $$('.dom').forEach(b => b.classList.toggle('on', b.dataset.v === S.reg.domla)); },
  async r4(el) {
    const r = S.reg; busy(el, true, 'Yaratilmoqda…');
    try { S.me = await api('/register', 'POST', {name: r.name, surname: r.sur, email: r.mail, password: r.pass, lang: r.lang, daily: r.daily, monthly: r.daily * 30, domla: r.domla, plan: r.plan}); boom(); }
    catch (e) { busy(el, false); toast(e.msg); if (e.status === 409 || e.status === 400) R1(); }
  },
  async dologin(el) {
    const m = $('#l-mail'), p = $('#l-pass');
    if (!m.value.trim() || !p.value) { bad(m); $('#err').textContent = 'Email va parolni yoz'; return; }
    busy(el, true, 'Kirilmoqda…');
    try { S.me = await api('/login', 'POST', {email: m.value.trim(), password: p.value}); await enterApp(); }
    catch (e) { busy(el, false); $('#err').textContent = e.msg; bad(p); }
  },
  say: el => speak(el.dataset.t, S.me.lang),
  async check(el) {
    const g = $('#gap'), v = g.value.trim(), res = $('#res');
    if (v.length < 3) { bad(g); return toast('Gap yoz, boʻsh qoldirma 😏'); }
    busy(el, true, 'Domla oʻqiyapti…');
    try { const r = await api('/check', 'POST', {word_id: S.cur.id, sentence: v}); res.style.display = 'block'; res.textContent = r.reply; res.classList.add('pop'); S.me.done = r.done; S.me.streak = r.streak; paintTop();
      if (r.ok) { burst(); setTimeout(async () => { await refreshMe(); if (S.view === 'learn') setView('learn'); }, 2400); } }
    catch (e) { fail(e); } busy(el, false);
  },
  flip: el => el.classList.toggle('f'),
  async rev(el) {
    if (!S.rev) return; const ok = el.dataset.v === '1';
    try { const r = await api('/review', 'POST', {word_id: S.rev.id, remembered: ok}); S.me.streak = r.streak; paintTop(); if (ok) burst(); toast(ok ? rnd(['Barakalla! 🧠', 'Miyang ishlayapti 💪']) : 'Hechqisi yoʻq, yana koʻrsatamiz 😅'); setView('review'); }
    catch (e) { fail(e); }
  },
  async qstart(el) { busy(el, true, 'Tayyorlanmoqda…');
    try { const r = await api('/quiz'); S.Q = {qs: r.questions, i: 0, score: 0, wrong: []}; S.me.limits.quiz_left--; renderQ(); } catch (e) { busy(el, false); fail(e); } },
  qans(el) {
    const Q = S.Q, q = Q.qs[Q.i], i = +el.dataset.i; if (Q.lock) return; Q.lock = true;
    $$('.opt').forEach((b, k) => { if (k === q.answer) b.classList.add('ok'); else if (k === i) b.classList.add('bad'); });
    if (i === q.answer) Q.score++; else Q.wrong.push(q.word_id);
    setTimeout(() => { Q.lock = false; Q.i++; renderQ(); }, 1000);
  },
  async essay(el) {
    const t = $('#es'), v = t.value.trim(); if (v.length < 30) { bad(t); return toast('Kamida 30 belgi yoz ✍️'); }
    busy(el, true, 'Domla oʻqiyapti…');
    try { const r = await api('/essay', 'POST', {text: v}); $('#eres').innerHTML = `<div class="card col pop"><h3>Domla fikri ${S.me.domla === 'h' ? '😄' : '😤'}</h3><div style="white-space:pre-wrap;font-weight:600">${esc(r.reply)}</div></div>`; await refreshMe(); }
    catch (e) { fail(e); } busy(el, false);
  },
  topic(el) { S.topic = el.dataset.t; $$('[data-act=topic]').forEach(b => b.classList.toggle('on', b === el)); },
  mic() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition, mic = $('#mic'), box = $('#sp-txt');
    if (!SR) return toast('Brauzering ovozni tanimaydi. Chrome ishlat yoki matnni oʻzing yoz');
    if (S.rec) { S.rec.stop(); return; }
    const rec = S.rec = new SR(); rec.lang = S.me.lang === 'ru' ? 'ru-RU' : 'en-US'; rec.interimResults = true; rec.continuous = true; const base = box.value ? box.value + ' ' : '';
    rec.onresult = e => { let t = ''; for (let i = 0; i < e.results.length; i++) t += e.results[i][0].transcript; box.value = base + t; };
    rec.onend = () => { S.rec = null; mic.classList.remove('rec'); }; rec.onerror = () => toast('Mikrofon ishlamadi, ruxsat berilganini tekshir');
    rec.start(); mic.classList.add('rec');
  },
  async speaksend(el) {
    const box = $('#sp-txt'), v = box.value.trim(); if (v.length < 5) { bad(box); return toast('Avval gapir yoki matn yoz 🎤'); }
    if (S.rec) S.rec.stop(); busy(el, true, 'Domla oʻqiyapti…');
    try { const r = await api('/speak', 'POST', {text: v, topic: S.topic || ''}); $('#sres').innerHTML = `<div class="card col pop"><h3>Domla fikri ${S.me.domla === 'h' ? '😄' : '😤'}</h3><div style="white-space:pre-wrap;font-weight:600">${esc(r.reply)}</div></div>`; await refreshMe(); }
    catch (e) { fail(e); } busy(el, false);
  },
  bf(el) { S.bf = el.dataset.v; $$('[data-act=bf]').forEach(b => b.classList.toggle('on', b === el)); paintBook(); },
  async trial(el) {
    const m = S.me; if (m.trial_used || m.plan !== 'free') { window.open('https://t.me/' + S.plans.pay.replace('@', ''), '_blank'); return; }
    busy(el, true, 'Faollashtirilmoqda…');
    try { S.me = await api('/plan/start', 'POST', {plan: el.dataset.v}); paintTop(); burst(); toast(`🎉 ${S.me.plan.toUpperCase()} sinovi boshlandi!`); setView('plans'); } catch (e) { busy(el, false); fail(e); }
  },
  async tglink() { try { const r = await api('/telegram/link', 'POST'); window.open(r.url, '_blank'); let n = 0; const iv = setInterval(async () => { n++; await refreshMe(); if (S.me.tg || n > 30) { clearInterval(iv); if (S.view === 'settings') setView('settings'); } }, 3000); } catch (e) { fail(e); } },
  async notif() { await save({notify_on: !S.me.notify_on}); setView('settings'); },
  async logout() { try { await api('/logout', 'POST'); } catch (e) {} location.reload(); },
};
async function save(f) { try { S.me = await api('/settings', 'POST', f); paintTop(); } catch (e) { fail(e); } }

document.addEventListener('click', e => { const el = e.target.closest('[data-act]'); if (el && A[el.dataset.act]) A[el.dataset.act](el, e); });
document.addEventListener('change', async e => {
  const k = e.target.dataset && e.target.dataset.set; if (!k) return;
  const v = ['daily', 'notify_hour'].includes(k) ? +e.target.value : e.target.value;
  await save(k === 'daily' ? {daily: v, monthly: v * 30} : {[k]: v}); if (k === 'lang') toast('Til oʻzgardi, yangi soʻzlar shu tilda chiqadi ✅'); if (k === 'domla') toast(v === 'h' ? 'Hazilkash domla 😄' : 'Qattiq ustoz 😤');
});
document.addEventListener('input', e => { if (e.target.id === 'es') $('#cnt').textContent = e.target.value.length + ' / 2000'; if (e.target.id === 'q') { clearTimeout(A.qt); A.qt = setTimeout(loadBook, 250); } });
document.addEventListener('keydown', e => { if (e.key === 'Enter' && e.target.tagName === 'INPUT' && e.target.closest('.pin')) { const b = $('.pin [data-primary]'); if (b) b.click(); } });

/* ---------- boshlash ---------- */
(async () => {
  try { S.plans = await api('/plans'); } catch (e) {}
  try { S.me = await api('/me'); await enterApp(); } catch (e) { splash(); }
})();
})();
